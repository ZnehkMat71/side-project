<?php
declare(strict_types=1);

session_start();

$dataFile = __DIR__ . DIRECTORY_SEPARATOR . 'assets.json';
$auditFile = __DIR__ . DIRECTORY_SEPARATOR . 'audit_log.json';
$maintenanceFile = __DIR__ . DIRECTORY_SEPARATOR . 'maintenance_tickets.json';
$departmentsFile = __DIR__ . DIRECTORY_SEPARATOR . 'departments.json';
$requestsFile = __DIR__ . DIRECTORY_SEPARATOR . 'asset_requests.json';
$procurementFile = __DIR__ . DIRECTORY_SEPARATOR . 'procurement_requests.json';
$reservationsFile = __DIR__ . DIRECTORY_SEPARATOR . 'reservations.json';
$barcodeChecksFile = __DIR__ . DIRECTORY_SEPARATOR . 'barcode_checks.json';
$assetHistoryFile = __DIR__ . DIRECTORY_SEPARATOR . 'asset_history.json';
$assetUploadsDir = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'assets';
if (!is_dir($assetUploadsDir)) {
	mkdir($assetUploadsDir, 0777, true);
}

function loadAssets(string $dataFile): array
{
	if (!file_exists($dataFile)) {
		$starterAssets = [
			[
				'id' => 'AST-1001',
				'name' => 'Dell Latitude 5420',
				'category' => 'Laptop',
				'department' => 'Engineering',
				'serial' => 'DL5420-8K2P',
				'status' => 'In use',
				'assigned_to' => 'Maya Patel',
				'location' => 'Manila Office',
				'purchase_date' => '2024-02-15',
				'warranty_until' => '2027-02-15',
				'cost' => 1450,
				'notes' => 'Standard developer laptop',
			],
			[
				'id' => 'AST-1002',
				'name' => 'HP LaserJet Pro M404',
				'category' => 'Printer',
				'department' => 'Finance',
				'serial' => 'HPM404-9910',
				'status' => 'Available',
				'assigned_to' => '',
				'location' => 'Manila Office',
				'purchase_date' => '2023-08-04',
				'warranty_until' => '2026-08-04',
				'cost' => 320,
				'notes' => 'Finance team printer',
			],
			[
				'id' => 'AST-1003',
				'name' => 'Cisco Meraki MR46',
				'category' => 'Network',
				'department' => 'Operations',
				'serial' => 'Q2XX-7L3D-4M8P',
				'status' => 'Maintenance',
				'assigned_to' => '',
				'location' => 'Server Room',
				'purchase_date' => '2022-11-20',
				'warranty_until' => '2027-11-20',
				'cost' => 780,
				'notes' => 'Replacement antenna ordered',
			],
		];
		file_put_contents($dataFile, json_encode($starterAssets, JSON_PRETTY_PRINT), LOCK_EX);
		return $starterAssets;
	}

	$assets = json_decode((string) file_get_contents($dataFile), true);
	if (!is_array($assets)) {
		return [];
	}

	return array_map(static function (array $asset): array {
		$asset['department'] = trim((string) ($asset['department'] ?? 'General'));
		if ($asset['department'] === '') {
			$asset['department'] = 'General';
		}
		return $asset;
	}, $assets);
}

function saveAssets(string $dataFile, array $assets): void
{
	file_put_contents($dataFile, json_encode(array_values($assets), JSON_PRETTY_PRINT), LOCK_EX);
}

function loadAuditEntries(string $auditFile): array
{
	if (!file_exists($auditFile)) {
		file_put_contents($auditFile, json_encode([], JSON_PRETTY_PRINT), LOCK_EX);
		return [];
	}

	$entries = json_decode((string) file_get_contents($auditFile), true);
	return is_array($entries) ? $entries : [];
}

function saveAuditEntries(string $auditFile, array $entries): void
{
	file_put_contents($auditFile, json_encode(array_values($entries), JSON_PRETTY_PRINT), LOCK_EX);
}

function recordAudit(string $auditFile, string $message): void
{
	$entries = loadAuditEntries($auditFile);
	$entries[] = [
		'timestamp' => date('Y-m-d H:i:s'),
		'message' => $message,
	];
	saveAuditEntries($auditFile, $entries);
}

function clean(string $value): string
{
	return trim($value);
}

function assetCost(array $asset): float
{
	return (float) ($asset['cost'] ?? 0);
}

function money(float $amount): string
{
	return '$' . number_format($amount, 2);
}

function daysUntil(string $date): int
{
	if ($date === '') {
		return 0;
	}

	$target = DateTimeImmutable::createFromFormat('Y-m-d', $date);
	if ($target === false) {
		return 0;
	}

	$today = new DateTimeImmutable('today');
	$interval = $today->diff($target);
	return (int) $interval->format('%r%a');
}

function statusChipClass(string $status): string
{
	$status = strtolower($status);
	if ($status === 'maintenance') {
		return 'maintenance';
	}
	if ($status === 'retired') {
		return 'retired';
	}
	return '';
}

function assetAgeMonths(array $asset): int
{
	$purchaseDate = (string) ($asset['purchase_date'] ?? '');
	if ($purchaseDate === '') {
		return 0;
	}

	$purchase = DateTimeImmutable::createFromFormat('Y-m-d', $purchaseDate);
	if ($purchase === false) {
		return 0;
	}

	$today = new DateTimeImmutable('today');
	$interval = $today->diff($purchase);
	return ((int) $interval->format('%y')) * 12 + (int) $interval->format('%m');
}

function assetCurrentValue(array $asset): float
{
	$cost = (float) ($asset['cost'] ?? 0);
	if ($cost <= 0) {
		return 0;
	}

	$months = assetAgeMonths($asset);
	if ($months <= 0) {
		return $cost;
	}

	$depreciationRate = min(0.8, ($months / 60) * 0.8);
	return max(0, $cost * (1 - $depreciationRate));
}

function shouldReplaceAsset(array $asset): bool
{
	$months = assetAgeMonths($asset);
	return $months >= 36 && !in_array((string) ($asset['status'] ?? ''), ['Retired'], true);
}

function qrCodeUrl(string $value): string
{
	return 'https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=' . urlencode($value);
}

function saveAssetPhoto(array $file, string $existingPhoto = ''): string
{
	if (!isset($file['tmp_name']) || !is_string($file['tmp_name']) || $file['tmp_name'] === '' || !is_uploaded_file($file['tmp_name'])) {
		return $existingPhoto;
	}

	$dimensions = @getimagesize($file['tmp_name']);
	if ($dimensions === false) {
		return $existingPhoto;
	}

	$mime = (int) ($dimensions[2] ?? 0);
	$ext = match ($mime) {
		IMAGETYPE_JPEG => 'jpg',
		IMAGETYPE_PNG => 'png',
		IMAGETYPE_WEBP => 'webp',
		IMAGETYPE_GIF => 'gif',
		default => '',
	};

	if ($ext === '') {
		return $existingPhoto;
	}

	$name = pathinfo((string) ($file['name'] ?? 'asset'), PATHINFO_FILENAME);
	$name = preg_replace('/[^A-Za-z0-9_-]+/', '_', $name) ?: 'asset';
	$filename = $name . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
	$target = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . $filename;

	if (move_uploaded_file($file['tmp_name'], $target)) {
		if ($existingPhoto !== '' && $existingPhoto !== 'uploads/assets/' . $filename) {
			$previousFile = __DIR__ . DIRECTORY_SEPARATOR . ltrim($existingPhoto, '/\\');
			if (is_file($previousFile)) {
				unlink($previousFile);
			}
		}
		return 'uploads/assets/' . $filename;
	}

	return $existingPhoto;
}

function defaultDepartmentOptions(): array
{
	return ['General', 'Engineering', 'Finance', 'HR', 'Operations', 'Support', 'Sales', 'Executive'];
}

function loadDepartments(string $departmentsFile): array
{
	$defaults = defaultDepartmentOptions();
	if (!file_exists($departmentsFile)) {
		file_put_contents($departmentsFile, json_encode($defaults, JSON_PRETTY_PRINT), LOCK_EX);
		return $defaults;
	}

	$values = json_decode((string) file_get_contents($departmentsFile), true);
	$items = [];
	if (is_array($values)) {
		foreach ($values as $value) {
			$clean = trim((string) $value);
			if ($clean !== '') {
				$items[] = $clean;
			}
		}
	}

	return array_values(array_unique(array_merge($defaults, $items)));
}

function saveDepartments(string $departmentsFile, array $departments): void
{
	file_put_contents($departmentsFile, json_encode(array_values($departments), JSON_PRETTY_PRINT), LOCK_EX);
}

function departmentOptions(string $departmentsFile): array
{
	return loadDepartments($departmentsFile);
}

function loadMaintenanceTickets(string $maintenanceFile): array
{
	if (!file_exists($maintenanceFile)) {
		file_put_contents($maintenanceFile, json_encode([], JSON_PRETTY_PRINT), LOCK_EX);
		return [];
	}

	$tickets = json_decode((string) file_get_contents($maintenanceFile), true);
	return is_array($tickets) ? $tickets : [];
}

function saveMaintenanceTickets(string $maintenanceFile, array $tickets): void
{
	file_put_contents($maintenanceFile, json_encode(array_values($tickets), JSON_PRETTY_PRINT), LOCK_EX);
}

function loadAssetRequests(string $requestsFile): array
{
	if (!file_exists($requestsFile)) {
		file_put_contents($requestsFile, json_encode([], JSON_PRETTY_PRINT), LOCK_EX);
		return [];
	}

	$requests = json_decode((string) file_get_contents($requestsFile), true);
	return is_array($requests) ? $requests : [];
}

function saveAssetRequests(string $requestsFile, array $requests): void
{
	file_put_contents($requestsFile, json_encode(array_values($requests), JSON_PRETTY_PRINT), LOCK_EX);
}

function loadProcurementRequests(string $procurementFile): array
{
	if (!file_exists($procurementFile)) {
		file_put_contents($procurementFile, json_encode([], JSON_PRETTY_PRINT), LOCK_EX);
		return [];
	}

	$requests = json_decode((string) file_get_contents($procurementFile), true);
	return is_array($requests) ? $requests : [];
}

function saveProcurementRequests(string $procurementFile, array $requests): void
{
	file_put_contents($procurementFile, json_encode(array_values($requests), JSON_PRETTY_PRINT), LOCK_EX);
}

function loadBarcodeChecks(string $barcodeChecksFile): array
{
	if (!file_exists($barcodeChecksFile)) {
		file_put_contents($barcodeChecksFile, json_encode([], JSON_PRETTY_PRINT), LOCK_EX);
		return [];
	}

	$entries = json_decode((string) file_get_contents($barcodeChecksFile), true);
	return is_array($entries) ? $entries : [];
}

function saveBarcodeChecks(string $barcodeChecksFile, array $entries): void
{
	file_put_contents($barcodeChecksFile, json_encode(array_values($entries), JSON_PRETTY_PRINT), LOCK_EX);
}

function loadReservations(string $reservationsFile): array
{
	if (!file_exists($reservationsFile)) {
		file_put_contents($reservationsFile, json_encode([], JSON_PRETTY_PRINT), LOCK_EX);
		return [];
	}

	$reservations = json_decode((string) file_get_contents($reservationsFile), true);
	return is_array($reservations) ? $reservations : [];
}

function saveReservations(string $reservationsFile, array $reservations): void
{
	file_put_contents($reservationsFile, json_encode(array_values($reservations), JSON_PRETTY_PRINT), LOCK_EX);
}

function loadAssetHistory(string $assetHistoryFile): array
{
	if (!file_exists($assetHistoryFile)) {
		file_put_contents($assetHistoryFile, json_encode([], JSON_PRETTY_PRINT), LOCK_EX);
		return [];
	}

	$history = json_decode((string) file_get_contents($assetHistoryFile), true);
	return is_array($history) ? $history : [];
}

function saveAssetHistory(string $assetHistoryFile, array $history): void
{
	file_put_contents($assetHistoryFile, json_encode(array_values($history), JSON_PRETTY_PRINT), LOCK_EX);
}

function recordAssetHistory(string $assetHistoryFile, string $assetId, string $event, string $details): void
{
	$history = loadAssetHistory($assetHistoryFile);
	$history[] = [
		'asset_id' => $assetId,
		'event' => $event,
		'details' => $details,
		'timestamp' => date('Y-m-d H:i:s'),
	];
	saveAssetHistory($assetHistoryFile, $history);
}

function userAccounts(): array
{
	return [
		'admin' => ['password' => 'admin123', 'role' => 'admin'],
		'manager' => ['password' => 'manager123', 'role' => 'manager'],
		'staff' => ['password' => 'staff123', 'role' => 'staff'],
	];
}

function canViewPage(string $role, string $view): bool
{
	$allowed = [
		'admin' => ['overview', 'inventory', 'process', 'guide', 'departments', 'audit', 'login', 'detail', 'label', 'maintenance', 'requests', 'procurement', 'depreciation', 'reservations', 'lifecycle', 'scan', 'barcode'],
		'manager' => ['overview', 'inventory', 'process', 'guide', 'departments', 'audit', 'login', 'detail', 'label', 'maintenance', 'requests', 'procurement', 'depreciation', 'reservations', 'lifecycle', 'scan', 'barcode'],
		'staff' => ['overview', 'inventory', 'guide', 'login', 'detail', 'label', 'requests', 'procurement', 'depreciation', 'reservations', 'lifecycle', 'scan', 'barcode'],
	];

	return in_array($view, $allowed[$role] ?? ['overview'], true);
}

function canManageAssets(string $role): bool
{
	return in_array($role, ['admin', 'manager'], true);
}

$assets = loadAssets($dataFile);
$auditEntries = loadAuditEntries($auditFile);
$maintenanceTickets = loadMaintenanceTickets($maintenanceFile);
$assetRequests = loadAssetRequests($requestsFile);
$procurementRequests = loadProcurementRequests($procurementFile);
$reservations = loadReservations($reservationsFile);
$barcodeChecks = loadBarcodeChecks($barcodeChecksFile);
$assetHistory = loadAssetHistory($assetHistoryFile);
$departments = departmentOptions($departmentsFile);
$message = '';
$messageType = 'success';
$editingAsset = null;
$scanLookupValue = '';
$scanResults = [];
$view = in_array($_GET['view'] ?? 'overview', ['overview', 'inventory', 'process', 'guide', 'departments', 'audit', 'login', 'detail', 'label', 'maintenance', 'requests', 'procurement', 'depreciation', 'reservations', 'barcode', 'lifecycle', 'scan'], true) ? (string) ($_GET['view'] ?? 'overview') : 'overview';
$loginUser = $_SESSION['user'] ?? null;
$loginRole = $_SESSION['role'] ?? 'staff';
$userAccounts = userAccounts();

if (($loginUser === null || $loginUser === '') && $view !== 'login') {
	$view = 'login';
}

if ($loginUser !== null && $loginUser !== '' && !canViewPage($loginRole, $view)) {
	$view = 'overview';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$action = $_POST['action'] ?? '';

	if ($action === 'login') {
		$username = clean((string) ($_POST['username'] ?? ''));
		$password = (string) ($_POST['password'] ?? '');
		$validUser = $userAccounts[$username] ?? null;
		if ($validUser !== null && $validUser['password'] === $password) {
			$_SESSION['user'] = $username;
			$_SESSION['role'] = $validUser['role'];
			$loginUser = $username;
			$loginRole = $validUser['role'];
			$view = 'overview';
			$message = 'Welcome back, ' . ucfirst($validUser['role']) . '.';
		} else {
			$message = 'Invalid username or password.';
			$messageType = 'error';
			$view = 'login';
		}
	}

	if ($action === 'logout') {
		$_SESSION = [];
		session_destroy();
		header('Location: index.php?view=login');
		exit;
	}

	if ($action === 'save_department') {
		if (!canManageAssets($loginRole)) {
			$message = 'You do not have permission to manage departments.';
			$messageType = 'error';
		} else {
			$newDepartment = clean((string) ($_POST['new_department'] ?? ''));
			if ($newDepartment !== '') {
				$existing = departmentOptions($departmentsFile);
				if (!in_array($newDepartment, $existing, true)) {
					$existing[] = $newDepartment;
					saveDepartments($departmentsFile, $existing);
					$departments = $existing;
					$message = 'Department added successfully.';
				} else {
					$message = 'That department already exists.';
					$messageType = 'error';
				}
			} else {
				$message = 'Department name cannot be empty.';
				$messageType = 'error';
			}
		}
	}

	if ($action === 'transfer_asset') {
		$assetId = clean((string) ($_POST['asset_id'] ?? ''));
		$newOwner = clean((string) ($_POST['new_owner'] ?? ''));
		$newLocation = clean((string) ($_POST['new_location'] ?? ''));
		$newDepartment = clean((string) ($_POST['new_department'] ?? ''));
		if ($assetId === '' || $newOwner === '' || $newLocation === '') {
			$message = 'Asset, new owner, and location are required to transfer an asset.';
			$messageType = 'error';
		} else {
			$updated = false;
			foreach ($assets as $index => $asset) {
				if ($asset['id'] === $assetId) {
					$assets[$index]['assigned_to'] = $newOwner;
					$assets[$index]['location'] = $newLocation;
					if ($newDepartment !== '') {
						$assets[$index]['department'] = $newDepartment;
					}
					$assets[$index]['status'] = 'In use';
					$updated = true;
					break;
				}
			}
			if ($updated) {
				saveAssets($dataFile, $assets);
				$message = 'Asset transferred successfully.';
				recordAudit($auditFile, 'Transferred asset: ' . $assetId . ' to ' . $newOwner . ' at ' . $newLocation);
				recordAssetHistory($assetHistoryFile, $assetId, 'Transfer', 'Assigned to ' . $newOwner . ' in ' . $newLocation . ($newDepartment !== '' ? ' / ' . $newDepartment : ''));
			} else {
				$message = 'Asset not found for transfer.';
				$messageType = 'error';
			}
		}
	}

	if ($action === 'retire_asset') {
		$assetId = clean((string) ($_POST['asset_id'] ?? ''));
		$reason = clean((string) ($_POST['retire_reason'] ?? 'End of lifecycle'));
		$updated = false;
		foreach ($assets as $index => $asset) {
			if ($asset['id'] === $assetId) {
				$assets[$index]['status'] = 'Retired';
				$assets[$index]['assigned_to'] = '';
				$updated = true;
				break;
			}
		}
		if ($updated) {
			saveAssets($dataFile, $assets);
			$message = 'Asset retired successfully.';
			recordAudit($auditFile, 'Retired asset: ' . $assetId . ' (' . $reason . ')');
			recordAssetHistory($assetHistoryFile, $assetId, 'Retired', $reason);
		} else {
			$message = 'Asset not found for retirement.';
			$messageType = 'error';
		}
	}

	if ($action === 'save_ticket') {
		$ticket = [
			'id' => clean((string) ($_POST['ticket_id'] ?? '')) !== '' ? clean((string) ($_POST['ticket_id'] ?? '')) : 'MNT-' . random_int(1000, 9999),
			'asset_id' => clean((string) ($_POST['asset_id'] ?? '')),
			'title' => clean((string) ($_POST['title'] ?? '')),
			'description' => clean((string) ($_POST['description'] ?? '')),
			'priority' => clean((string) ($_POST['priority'] ?? 'Medium')),
			'status' => clean((string) ($_POST['status'] ?? 'Open')),
			'created_at' => date('Y-m-d H:i:s'),
		];

		if ($ticket['asset_id'] === '' || $ticket['title'] === '') {
			$message = 'Asset and title are required for maintenance tickets.';
			$messageType = 'error';
		} else {
			$maintenanceTickets = loadMaintenanceTickets($maintenanceFile);
			$updated = false;
			foreach ($maintenanceTickets as $index => $existingTicket) {
				if (($existingTicket['id'] ?? '') === $ticket['id']) {
					$maintenanceTickets[$index] = $ticket;
					$updated = true;
					break;
				}
			}
			if (!$updated) {
				$maintenanceTickets[] = $ticket;
			}
			saveMaintenanceTickets($maintenanceFile, $maintenanceTickets);
			$message = $updated ? 'Maintenance ticket updated.' : 'Maintenance ticket created.';
			recordAudit($auditFile, 'Maintenance ticket: ' . $ticket['title'] . ' for ' . $ticket['asset_id']);
		}
	}

	if ($action === 'scan_lookup') {
		$scanLookupValue = clean((string) ($_POST['lookup'] ?? ''));
		$view = 'scan';
		if ($scanLookupValue === '') {
			$message = 'Please enter an asset ID or serial number to scan.';
			$messageType = 'error';
		} else {
			$exactMatches = [];
			$relatedMatches = [];
			foreach ($assets as $asset) {
				$assetId = (string) ($asset['id'] ?? '');
				$serial = (string) ($asset['serial'] ?? '');
				$searchableFields = [
					$assetId,
					$serial,
					(string) ($asset['name'] ?? ''),
					(string) ($asset['category'] ?? ''),
					(string) ($asset['department'] ?? ''),
					(string) ($asset['assigned_to'] ?? ''),
					(string) ($asset['location'] ?? ''),
				];
				if (strcasecmp($assetId, $scanLookupValue) === 0 || strcasecmp($serial, $scanLookupValue) === 0) {
					$exactMatches[] = $asset;
				} elseif (count(array_filter($searchableFields, static fn (string $field): bool => $field !== '' && stripos($field, $scanLookupValue) !== false)) > 0) {
					$relatedMatches[] = $asset;
				}
			}
			$scanResults = array_slice(array_merge($exactMatches, $relatedMatches), 0, 12);
			if (count($scanResults) === 0) {
				$message = 'No asset matches that scan code.';
				$messageType = 'error';
			} else {
				$message = count($scanResults) === 1 ? 'Scan successful: asset found.' : 'Scan successful: ' . count($scanResults) . ' possible matches found.';
			}
		}
	}

	if ($action === 'save_request') {
		$request = [
			'id' => 'REQ-' . random_int(1000, 9999),
			'asset_name' => clean((string) ($_POST['asset_name'] ?? '')),
			'category' => clean((string) ($_POST['category'] ?? 'Other')),
			'requested_by' => clean((string) ($_POST['requested_by'] ?? $loginUser ?? 'Unknown user')),
			'quantity' => max(1, (int) ($_POST['quantity'] ?? 1)),
			'urgency' => clean((string) ($_POST['urgency'] ?? 'Medium')),
			'reason' => clean((string) ($_POST['reason'] ?? '')),
			'status' => 'Pending',
			'created_at' => date('Y-m-d H:i:s'),
		];

		if ($request['asset_name'] === '' || $request['reason'] === '') {
			$message = 'Asset name and reason are required for a request.';
			$messageType = 'error';
		} else {
			$assetRequests = loadAssetRequests($requestsFile);
			$assetRequests[] = $request;
			saveAssetRequests($requestsFile, $assetRequests);
			$message = 'Asset request submitted successfully.';
			recordAudit($auditFile, 'New asset request: ' . $request['asset_name'] . ' by ' . $request['requested_by']);
		}
	}

	if ($action === 'save_procurement') {
		$procurement = [
			'id' => 'PUR-' . random_int(1000, 9999),
			'item_name' => clean((string) ($_POST['item_name'] ?? '')),
			'vendor' => clean((string) ($_POST['vendor'] ?? '')),
			'category' => clean((string) ($_POST['category'] ?? 'Other')),
			'quantity' => max(1, (int) ($_POST['quantity'] ?? 1)),
			'unit_cost' => max(0, (float) ($_POST['unit_cost'] ?? 0)),
			'estimated_total' => max(0, (float) ($_POST['estimated_total'] ?? 0)),
			'requested_by' => clean((string) ($_POST['requested_by'] ?? $loginUser ?? 'Unknown user')),
			'urgency' => clean((string) ($_POST['urgency'] ?? 'Medium')),
			'reason' => clean((string) ($_POST['reason'] ?? '')),
			'status' => 'Pending',
			'created_at' => date('Y-m-d H:i:s'),
		];

		if ($procurement['item_name'] === '' || $procurement['vendor'] === '' || $procurement['reason'] === '') {
			$message = 'Item name, vendor, and reason are required for a procurement request.';
			$messageType = 'error';
		} else {
			$procurementRequests = loadProcurementRequests($procurementFile);
			$procurement['estimated_total'] = $procurement['quantity'] * $procurement['unit_cost'];
			$procurementRequests[] = $procurement;
			saveProcurementRequests($procurementFile, $procurementRequests);
			$message = 'Procurement request submitted successfully.';
			recordAudit($auditFile, 'New procurement request: ' . $procurement['item_name'] . ' from ' . $procurement['vendor']);
			$view = 'procurement';
		}
	}

	if ($action === 'save_reservation') {
		$assetId = clean((string) ($_POST['asset_id'] ?? ''));
		$startDate = clean((string) ($_POST['start_date'] ?? ''));
		$endDate = clean((string) ($_POST['end_date'] ?? ''));
		$reservedBy = clean((string) ($_POST['reserved_by'] ?? ($loginUser ?? 'Unknown user')));
		$purpose = clean((string) ($_POST['purpose'] ?? ''));

		if ($assetId === '' || $startDate === '' || $endDate === '') {
			$message = 'Asset, start date, and end date are required for a reservation.';
			$messageType = 'error';
		} else {
			$assetMatch = null;
			foreach ($assets as $asset) {
				if (($asset['id'] ?? '') === $assetId) {
					$assetMatch = $asset;
					break;
				}
			}

			if ($assetMatch === null) {
				$message = 'The selected asset ID does not exist.';
				$messageType = 'error';
			} else {
				$existingReservation = false;
				foreach ($reservations as $reservation) {
					if (($reservation['asset_id'] ?? '') !== $assetId || (($reservation['status'] ?? 'Approved') === 'Cancelled')) {
						continue;
					}
					$existingStart = (string) ($reservation['start_date'] ?? '');
					$existingEnd = (string) ($reservation['end_date'] ?? '');
					if ($existingStart !== '' && $existingEnd !== '' && $startDate <= $existingEnd && $endDate >= $existingStart) {
						$existingReservation = true;
						break;
					}
				}

				if ($existingReservation) {
					$message = 'This asset is already reserved for part of the selected date range.';
					$messageType = 'error';
				} else {
					$reservation = [
						'id' => 'RES-' . random_int(1000, 9999),
						'asset_id' => $assetId,
						'asset_name' => (string) ($assetMatch['name'] ?? 'Asset'),
						'reserved_by' => $reservedBy,
						'purpose' => $purpose !== '' ? $purpose : 'Team use',
						'start_date' => $startDate,
						'end_date' => $endDate,
						'status' => 'Approved',
						'created_at' => date('Y-m-d H:i:s'),
					];
					$reservations[] = $reservation;
					saveReservations($reservationsFile, $reservations);
					$message = 'Asset reservation created successfully.';
					recordAudit($auditFile, 'Reservation for ' . $assetId . ' from ' . $startDate . ' to ' . $endDate . ' by ' . $reservedBy);
					$view = 'reservations';
				}
			}
		}
	}

	if ($action === 'cancel_reservation') {
		$reservationId = clean((string) ($_POST['reservation_id'] ?? ''));
		$updated = false;
		foreach ($reservations as $index => $reservation) {
			if (($reservation['id'] ?? '') === $reservationId) {
				$reservations[$index]['status'] = 'Cancelled';
				$updated = true;
				break;
			}
		}
		if (!$updated) {
			$message = 'Reservation not found.';
			$messageType = 'error';
		} else {
			saveReservations($reservationsFile, $reservations);
			$message = 'Reservation cancelled.';
			recordAudit($auditFile, 'Cancelled reservation: ' . $reservationId);
			$view = 'reservations';
		}
	}

	if ($action === 'toggle_barcode_check') {
		$assetId = clean((string) ($_POST['asset_id'] ?? ''));
		$type = clean((string) ($_POST['type'] ?? 'checkin'));
		$user = clean((string) ($_POST['user'] ?? ($loginUser ?? 'Unknown user')));
		$view = 'barcode';
		if ($assetId === '') {
			$message = 'Asset ID is required for barcode check-in/check-out.';
			$messageType = 'error';
		} elseif (!in_array($type, ['checkin', 'checkout'], true)) {
			$message = 'Invalid barcode action.';
			$messageType = 'error';
		} elseif (count(array_filter($assets, static fn (array $asset): bool => strcasecmp((string) ($asset['id'] ?? ''), $assetId) === 0)) === 0) {
			$message = 'Asset ID was not found in inventory.';
			$messageType = 'error';
		} else {
			$event = [
				'id' => 'BAR-' . random_int(1000, 9999),
				'asset_id' => $assetId,
				'type' => $type,
				'user' => $user,
				'timestamp' => date('Y-m-d H:i:s'),
			];
			$barcodeChecks = loadBarcodeChecks($barcodeChecksFile);
			$barcodeChecks[] = $event;
			saveBarcodeChecks($barcodeChecksFile, $barcodeChecks);
			$message = $type === 'checkout' ? 'Asset checked out successfully.' : 'Asset checked in successfully.';
			recordAudit($auditFile, 'Barcode ' . strtoupper($type) . ': ' . $assetId . ' by ' . $user);
		}
	}

	if ($action === 'respond_request') {
		if (!canManageAssets($loginRole)) {
			$message = 'You do not have permission to approve requests.';
			$messageType = 'error';
		} else {
			$requestId = clean((string) ($_POST['request_id'] ?? ''));
			$decision = clean((string) ($_POST['decision'] ?? 'approved'));
			$assetRequests = loadAssetRequests($requestsFile);
			foreach ($assetRequests as $index => $request) {
				if (($request['id'] ?? '') === $requestId) {
					$assetRequests[$index]['status'] = $decision === 'approved' ? 'Approved' : 'Rejected';
					$assetRequests[$index]['reviewed_by'] = $loginUser;
					$assetRequests[$index]['reviewed_at'] = date('Y-m-d H:i:s');
					break;
				}
			}
			saveAssetRequests($requestsFile, $assetRequests);
			$message = $decision === 'approved' ? 'Asset request approved.' : 'Asset request rejected.';
			recordAudit($auditFile, 'Request ' . $requestId . ' was ' . strtolower($decision) . ' by ' . $loginUser);
		}
	}

	if ($action === 'respond_procurement') {
		if (!canManageAssets($loginRole)) {
			$message = 'You do not have permission to approve procurement requests.';
			$messageType = 'error';
		} else {
			$requestId = clean((string) ($_POST['request_id'] ?? ''));
			$decision = clean((string) ($_POST['decision'] ?? 'approved'));
			$procurementRequests = loadProcurementRequests($procurementFile);
			foreach ($procurementRequests as $index => $request) {
				if (($request['id'] ?? '') === $requestId) {
					$procurementRequests[$index]['status'] = $decision === 'approved' ? 'Approved' : 'Rejected';
					$procurementRequests[$index]['reviewed_by'] = $loginUser;
					$procurementRequests[$index]['reviewed_at'] = date('Y-m-d H:i:s');
					break;
				}
			}
			saveProcurementRequests($procurementFile, $procurementRequests);
			$message = $decision === 'approved' ? 'Procurement request approved.' : 'Procurement request rejected.';
			recordAudit($auditFile, 'Procurement ' . $requestId . ' was ' . strtolower($decision) . ' by ' . $loginUser);
			$view = 'procurement';
		}
	}

	if ($action === 'save') {
		if (!canManageAssets($loginRole)) {
			$message = 'You do not have permission to modify inventory.';
			$messageType = 'error';
		} else {
			$id = clean((string) ($_POST['id'] ?? ''));
			$existingRecord = null;
			foreach ($assets as $assetCandidate) {
				if (($assetCandidate['id'] ?? '') === $id) {
					$existingRecord = $assetCandidate;
					break;
				}
			}
			$photoPath = $existingRecord['photo'] ?? '';
			if (isset($_FILES['photo']) && is_array($_FILES['photo'])) {
				$photoPath = saveAssetPhoto($_FILES['photo'], $photoPath);
			}
			$asset = [
				'id' => $id !== '' ? $id : 'AST-' . random_int(1000, 9999),
				'name' => clean((string) ($_POST['name'] ?? '')),
				'category' => clean((string) ($_POST['category'] ?? 'Other')),
				'department' => clean((string) ($_POST['department'] ?? 'General')),
				'serial' => clean((string) ($_POST['serial'] ?? '')),
				'status' => clean((string) ($_POST['status'] ?? 'Available')),
				'assigned_to' => clean((string) ($_POST['assigned_to'] ?? '')),
				'location' => clean((string) ($_POST['location'] ?? '')),
				'purchase_date' => clean((string) ($_POST['purchase_date'] ?? '')),
				'warranty_until' => clean((string) ($_POST['warranty_until'] ?? '')),
				'cost' => max(0, (float) ($_POST['cost'] ?? 0)),
				'notes' => clean((string) ($_POST['notes'] ?? '')),
				'photo' => $photoPath,
			];

			if ($asset['name'] === '' || $asset['serial'] === '') {
				$message = 'Asset name and serial number are required.';
				$messageType = 'error';
				$editingAsset = $asset;
			} else {
				$found = false;
				foreach ($assets as $index => $existing) {
					if ($existing['id'] === $asset['id']) {
						$assets[$index] = $asset;
						$found = true;
						break;
					}
				}
				if (!$found) {
					$assets[] = $asset;
				}
				saveAssets($dataFile, $assets);
				$message = $found ? 'Asset updated successfully.' : 'Asset registered successfully.';
				recordAudit($auditFile, ($found ? 'Updated' : 'Registered') . ' asset: ' . $asset['name'] . ' (' . $asset['id'] . ')');
			}
		}
	}

	if ($action === 'delete') {
		if (!canManageAssets($loginRole)) {
			$message = 'You do not have permission to remove inventory items.';
			$messageType = 'error';
		} else {
			$deleteId = clean((string) ($_POST['id'] ?? ''));
			$deletedAsset = null;
			foreach ($assets as $asset) {
				if ($asset['id'] === $deleteId) {
					$deletedAsset = $asset;
					break;
				}
			}
			$assets = array_values(array_filter($assets, static fn (array $asset): bool => $asset['id'] !== $deleteId));
			if ($deletedAsset !== null && !empty($deletedAsset['photo'] ?? '')) {
				$photoPath = __DIR__ . DIRECTORY_SEPARATOR . ltrim((string) $deletedAsset['photo'], '/\\');
				if (is_file($photoPath)) {
					unlink($photoPath);
				}
			}
			saveAssets($dataFile, $assets);
			$message = 'Asset removed from inventory.';
			if ($deletedAsset !== null) {
				recordAudit($auditFile, 'Removed asset: ' . ($deletedAsset['name'] ?? 'Unknown') . ' (' . $deleteId . ')');
			}
		}
	}
}

if (isset($_GET['edit'])) {
	foreach ($assets as $asset) {
		if ($asset['id'] === $_GET['edit']) {
			$editingAsset = $asset;
			break;
		}
	}
}

$detailAsset = null;
if (isset($_GET['detail'])) {
	foreach ($assets as $asset) {
		if ($asset['id'] === $_GET['detail']) {
			$detailAsset = $asset;
			if ($view !== 'label') {
				$view = 'detail';
			}
			break;
		}
	}
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$view = in_array($action, ['scan_lookup', 'toggle_barcode_check'], true) ? ($action === 'scan_lookup' ? 'scan' : 'barcode') : (($action === 'save' && $messageType === 'error') ? 'process' : 'inventory');
}

$search = clean((string) ($_GET['search'] ?? ''));
$statusFilter = clean((string) ($_GET['status'] ?? 'All'));
$departmentFilter = clean((string) ($_GET['department'] ?? 'All'));
$sort = in_array($_GET['sort'] ?? 'name_asc', ['name_asc', 'name_desc', 'status_asc', 'cost_desc', 'newest'], true) ? (string) ($_GET['sort'] ?? 'name_asc') : 'name_asc';

if (isset($_GET['export']) && $_GET['export'] === 'csv') {
	$exportAssets = $assets;
	if ($search !== '' || $statusFilter !== 'All' || $departmentFilter !== 'All') {
		$exportAssets = array_values(array_filter($assets, static function (array $asset) use ($search, $statusFilter, $departmentFilter): bool {
			$matchesSearch = $search === '' || stripos(implode(' ', $asset), $search) !== false;
			$matchesStatus = $statusFilter === 'All' || $asset['status'] === $statusFilter;
			$matchesDepartment = $departmentFilter === 'All' || ($asset['department'] ?? 'General') === $departmentFilter;
			return $matchesSearch && $matchesStatus && $matchesDepartment;
		}));
	}

	header('Content-Type: text/csv; charset=utf-8');
	header('Content-Disposition: attachment; filename="asset_inventory.csv"');
	$output = fopen('php://output', 'wb');
	fputcsv($output, ['ID', 'Name', 'Category', 'Department', 'Serial', 'Status', 'Assigned To', 'Location', 'Purchase Date', 'Warranty Until', 'Cost', 'Notes']);
	foreach ($exportAssets as $asset) {
		fputcsv($output, [
			$asset['id'] ?? '',
			$asset['name'] ?? '',
			$asset['category'] ?? '',
			$asset['department'] ?? 'General',
			$asset['serial'] ?? '',
			$asset['status'] ?? '',
			$asset['assigned_to'] ?? '',
			$asset['location'] ?? '',
			$asset['purchase_date'] ?? '',
			$asset['warranty_until'] ?? '',
			$asset['cost'] ?? 0,
			$asset['notes'] ?? '',
		]);
	}
	fclose($output);
	exit;
}

$filteredAssets = array_values(array_filter($assets, static function (array $asset) use ($search, $statusFilter, $departmentFilter): bool {
	$matchesSearch = $search === '' || stripos(implode(' ', $asset), $search) !== false;
	$matchesStatus = $statusFilter === 'All' || $asset['status'] === $statusFilter;
	$matchesDepartment = $departmentFilter === 'All' || ($asset['department'] ?? 'General') === $departmentFilter;
	return $matchesSearch && $matchesStatus && $matchesDepartment;
}));
usort($filteredAssets, static function (array $left, array $right) use ($sort): int {
	if ($sort === 'name_desc') {
		return strnatcasecmp($right['name'] ?? '', $left['name'] ?? '');
	}
	if ($sort === 'status_asc') {
		$statusOrder = ['Available' => 1, 'In use' => 2, 'Maintenance' => 3, 'Retired' => 4];
		$cmp = ($statusOrder[$left['status']] ?? 999) <=> ($statusOrder[$right['status']] ?? 999);
		if ($cmp !== 0) {
			return $cmp;
		}
		return strnatcasecmp($left['name'] ?? '', $right['name'] ?? '');
	}
	if ($sort === 'cost_desc') {
		$cmp = (float) ($right['cost'] ?? 0) <=> (float) ($left['cost'] ?? 0);
		if ($cmp !== 0) {
			return $cmp;
		}
		return strnatcasecmp($left['name'] ?? '', $right['name'] ?? '');
	}
	if ($sort === 'newest') {
		$leftDate = (string) ($left['purchase_date'] ?? '');
		$rightDate = (string) ($right['purchase_date'] ?? '');
		$cmp = strcmp($rightDate, $leftDate);
		if ($cmp !== 0) {
			return $cmp;
		}
		return strnatcasecmp($left['name'] ?? '', $right['name'] ?? '');
	}
	return strnatcasecmp($left['name'] ?? '', $right['name'] ?? '');
});

$counts = [
	'total' => count($assets),
	'in_use' => count(array_filter($assets, static fn (array $asset): bool => $asset['status'] === 'In use')),
	'available' => count(array_filter($assets, static fn (array $asset): bool => $asset['status'] === 'Available')),
	'maintenance' => count(array_filter($assets, static fn (array $asset): bool => $asset['status'] === 'Maintenance')),
];

$departmentCounts = [];
foreach ($departments as $department) {
	$departmentCounts[$department] = count(array_filter($assets, static fn (array $asset): bool => ($asset['department'] ?? 'General') === $department));
}
$categories = ['Laptop', 'Desktop', 'Monitor', 'Mobile', 'Network', 'Printer', 'Other'];
$statuses = ['Available', 'In use', 'Maintenance', 'Retired'];
$currentMonth = date('Y-m');
$currentYear = date('Y');
$monthlySpend = array_sum(array_map(static fn (array $asset): float => str_starts_with((string) ($asset['purchase_date'] ?? ''), $currentMonth) ? assetCost($asset) : 0, $assets));
$yearlySpend = array_sum(array_map(static fn (array $asset): float => str_starts_with((string) ($asset['purchase_date'] ?? ''), $currentYear) ? assetCost($asset) : 0, $assets));
$totalValue = array_sum(array_map(static fn (array $asset): float => assetCost($asset), $assets));
$unassignedCount = count(array_filter($assets, static fn (array $asset): bool => trim((string) ($asset['assigned_to'] ?? '')) === ''));
$expiringSoonCount = count(array_filter($assets, static function (array $asset): bool {
	$days = daysUntil((string) ($asset['warranty_until'] ?? ''));
	return $days > 0 && $days <= 90;
}));
$warrantyAlerts = array_values(array_filter($assets, static function (array $asset): bool {
	$days = daysUntil((string) ($asset['warranty_until'] ?? ''));
	return $days > 0 && $days <= 120;
}));
$categorySpend = [];
foreach ($categories as $category) {
	$categorySpend[$category] = array_sum(array_map(static fn (array $asset): float => ($asset['category'] ?? '') === $category ? assetCost($asset) : 0, $assets));
}
$maxCategorySpend = max(1, ...array_values($categorySpend));
$statusProgress = [];
foreach ($statuses as $status) {
	$statusProgress[$status] = $counts['total'] > 0 ? (int) round(count(array_filter($assets, static fn (array $asset): bool => ($asset['status'] ?? '') === $status)) / $counts['total'] * 100) : 0;
}
$recentAssets = array_slice(array_reverse($assets), 0, 3);
$maintenanceQueue = array_values(array_filter($maintenanceTickets, static fn (array $ticket): bool => ($ticket['status'] ?? 'Open') !== 'Completed'));
$pendingRequests = array_values(array_filter($assetRequests, static fn (array $request): bool => ($request['status'] ?? 'Pending') === 'Pending'));
$pendingProcurements = array_values(array_filter($procurementRequests, static fn (array $request): bool => ($request['status'] ?? 'Pending') === 'Pending'));
$activeReservations = array_values(array_filter($reservations, static fn (array $reservation): bool => ($reservation['status'] ?? 'Approved') !== 'Cancelled'));
$lifecycleEvents = array_slice(array_reverse($assetHistory), 0, 8);
$recentAuditEntries = array_slice(array_reverse($auditEntries), 0, 5);
$maintenancePreview = array_slice(array_reverse($maintenanceQueue), 0, 3);
$requestPreview = array_slice(array_reverse($pendingRequests), 0, 3);
$procurementPreview = array_slice(array_reverse($pendingProcurements), 0, 3);
$reservationPreview = array_slice(array_reverse($activeReservations), 0, 3);
$replacementCandidates = array_values(array_filter($assets, static fn (array $asset): bool => shouldReplaceAsset($asset)));
$depreciatedAssets = array_values(array_map(static function (array $asset): array {
	$asset['age_months'] = assetAgeMonths($asset);
	$asset['estimated_value'] = assetCurrentValue($asset);
	return $asset;
}, $assets));
$replacementValue = array_sum(array_map(static fn (array $asset): float => assetCurrentValue($asset), $replacementCandidates));
$barcodeCheckCount = count($barcodeChecks);
$checkoutCount = count(array_filter($barcodeChecks, static fn (array $entry): bool => ($entry['type'] ?? 'checkin') === 'checkout'));
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Asset Ledger | IT Inventory</title>
	<style>
		:root { --ink:#17232b; --muted:#68777d; --line:#dfe7e5; --paper:#f5f7f4; --white:#fff; --teal:#087f76; --teal-dark:#075d59; --coral:#ed7259; --gold:#d9a441; }
		* { box-sizing:border-box; }
		body { margin:0; color:var(--ink); background:var(--paper); font-family:Georgia, 'Times New Roman', serif; }
		button, input, select, textarea { font:inherit; }
		.shell { display:grid; grid-template-columns:235px minmax(0, 1fr); min-height:100vh; }
		aside { color:#eef8f4; background:var(--teal-dark); padding:28px 20px; }
		.brand { display:flex; gap:12px; align-items:center; margin-bottom:60px; }
		.mark { display:grid; place-items:center; width:38px; height:38px; color:var(--teal-dark); background:#c8eee5; border-radius:10px; font-weight:bold; }
		.brand strong { display:block; font-size:18px; letter-spacing:.02em; }
		.brand small { color:#aad7cf; font:12px Arial, sans-serif; }
		nav a { display:block; padding:12px 14px; margin:7px 0; color:#badbd4; border-radius:8px; text-decoration:none; font:14px Arial, sans-serif; }
		nav a.active, nav a:hover { color:#fff; background:rgba(255,255,255,.12); }
		.side-note { position:absolute; bottom:25px; width:190px; padding-top:18px; border-top:1px solid rgba(255,255,255,.16); color:#a9cec7; font:12px/1.5 Arial, sans-serif; }
		main { width:min(1400px, 100%); min-width:0; padding:40px clamp(22px, 5vw, 72px); }
		.topline { display:flex; justify-content:space-between; align-items:flex-start; gap:20px; margin-bottom:30px; }
		h1 { margin:0 0 7px; font-size:clamp(30px, 4vw, 46px); font-weight:normal; letter-spacing:-.03em; }
		.intro { margin:0; color:var(--muted); font:14px Arial, sans-serif; }
		.button { display:inline-flex; align-items:center; justify-content:center; border:0; border-radius:7px; padding:12px 16px; color:#fff; background:var(--coral); cursor:pointer; font:bold 13px Arial, sans-serif; text-decoration:none; }
		.button:hover { background:#d85d48; }
		.button.secondary { color:var(--teal-dark); background:#d9eeea; }
		.stats { display:grid; grid-template-columns:repeat(4, 1fr); gap:14px; margin-bottom:32px; }
		.stat { padding:20px; background:var(--white); border:1px solid var(--line); border-top:3px solid var(--teal); border-radius:8px; }
		.stat:nth-child(2) { border-top-color:var(--coral); } .stat:nth-child(3) { border-top-color:var(--gold); } .stat:nth-child(4) { border-top-color:#8d9da3; }
		.stat span { display:block; color:var(--muted); font:11px Arial, sans-serif; text-transform:uppercase; letter-spacing:.08em; }
		.stat strong { display:block; margin-top:8px; font-size:31px; font-weight:normal; }
		.workspace { display:grid; grid-template-columns:minmax(0, 1fr) 330px; gap:24px; align-items:start; }
		.workspace.single-column { display:block; max-width:720px; }
		.panel { background:var(--white); border:1px solid var(--line); border-radius:8px; overflow:hidden; }
		.panel-heading { display:flex; align-items:center; justify-content:space-between; gap:14px; padding:18px 20px; border-bottom:1px solid var(--line); }
		.panel-heading h2 { margin:0; font-size:20px; font-weight:normal; }
		.panel-meta, .report-period { display:block; margin-top:5px; color:var(--muted); font:11px Arial, sans-serif; }
		.toolbar { display:flex; gap:8px; padding:14px 20px; background:#fbfcfa; border-bottom:1px solid var(--line); }
		input, select, textarea { width:100%; padding:11px 12px; color:var(--ink); border:1px solid #cbd8d5; border-radius:5px; background:#fff; outline:none; font:13px Arial, sans-serif; }
		input:focus, select:focus, textarea:focus { border-color:var(--teal); box-shadow:0 0 0 3px rgba(8,127,118,.1); }
		.toolbar input { flex:1; } .toolbar select { width:145px; }
		table { width:100%; border-collapse:collapse; text-align:left; }
		th { padding:12px 20px; color:var(--muted); background:#fbfcfa; font:bold 10px Arial, sans-serif; letter-spacing:.07em; text-transform:uppercase; }
		td { padding:16px 20px; border-top:1px solid #edf1ef; font-size:14px; vertical-align:middle; }
		td small { display:block; margin-top:4px; color:var(--muted); font:11px Arial, sans-serif; }
		.badge { display:inline-block; padding:5px 8px; border-radius:20px; color:var(--teal-dark); background:#dff2ed; font:bold 10px Arial, sans-serif; }
		.badge.maintenance { color:#76500a; background:#fff0c9; } .badge.retired { color:#697278; background:#e8ecec; }
		.actions { display:flex; gap:10px; justify-content:flex-end; flex-wrap:wrap; }
		.actions a:not(.button), .actions button:not(.button) { padding:0; color:var(--teal); border:0; background:none; cursor:pointer; font:12px Arial, sans-serif; text-decoration:none; }
		.actions button:not(.button) { color:var(--coral); }
		.form { padding:20px; } .form h3 { margin:0 0 5px; font-size:21px; font-weight:normal; }
		.form p { margin:0 0 20px; color:var(--muted); font:12px/1.5 Arial, sans-serif; }
		.field { margin-bottom:13px; } .field label { display:block; margin-bottom:6px; color:#526168; font:bold 11px Arial, sans-serif; }
		.form-grid { display:grid; grid-template-columns:1fr 1fr; gap:0 10px; } .full { grid-column:1 / -1; }
		textarea { min-height:70px; resize:vertical; } .form-actions { display:flex; gap:8px; margin-top:17px; }
		.overview-grid { display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:24px; max-width:900px; }
		.report-grid { display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:24px; max-width:1050px; }
		.overview-welcome { display:flex; align-items:center; justify-content:space-between; gap:24px; margin-bottom:24px; padding:22px 26px; color:#fff; background:linear-gradient(110deg, var(--teal-dark), #159b91); border-radius:10px; box-shadow:0 10px 24px rgba(7,93,89,.14); }
		.overview-welcome h2 { margin:5px 0 6px; font-size:26px; font-weight:normal; }
		.overview-welcome p { margin:0; color:#d8f0eb; font:13px/1.5 Arial, sans-serif; }
		.overview-welcome .button { flex-shrink:0; color:var(--teal-dark); background:#fff; }
		.overview-welcome .button:hover { background:#e8faf5; }
		.eyebrow { color:#b9e9e1; font:bold 10px Arial, sans-serif; letter-spacing:.12em; text-transform:uppercase; }
		.dashboard-grid { display:grid; grid-template-columns:minmax(0, 1.55fr) minmax(260px, .75fr); gap:24px; max-width:1050px; }
		.dashboard-grid .category-chart { grid-column:auto; }
		.snapshot-card { min-width:0; }
		.snapshot-value { padding:22px 20px 18px; border-bottom:1px solid var(--line); }
		.snapshot-value span, .snapshot-list span { display:block; color:var(--muted); font:11px Arial, sans-serif; }
		.snapshot-value strong { display:block; margin-top:7px; color:var(--ink); font:normal 30px Georgia, serif; }
		.snapshot-list { padding:4px 20px 13px; }
		.snapshot-list div { display:flex; justify-content:space-between; align-items:center; padding:12px 0; border-bottom:1px solid #edf1ef; font:13px Arial, sans-serif; }
		.snapshot-list div:last-child { border-bottom:0; }
		.snapshot-list strong { color:var(--ink); font-size:18px; font-weight:normal; }
		.overview-grid-compact { margin-top:24px; max-width:1050px; }
		.overview-grid-compact .panel-heading { padding-bottom:14px; }
		.overview-list { padding-top:14px; padding-bottom:10px; }
		.overview-list p { display:flex; justify-content:space-between; align-items:baseline; gap:18px; margin:0; padding:11px 0; border-bottom:1px solid #edf1ef; }
		.overview-list p:last-child { border-bottom:0; }
		.overview-list strong { display:block; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
		.overview-list span { flex-shrink:0; color:var(--muted); font-size:12px; }
		.inventory-panel { overflow-x:auto; }
		.inventory-panel .panel-heading { flex-wrap:wrap; }
		.inventory-table { table-layout:fixed; min-width:1500px; }
		.inventory-table th, .inventory-table td { padding-left:14px; padding-right:14px; }
		.inventory-table th:nth-child(1) { width:9%; } .inventory-table th:nth-child(2) { width:14%; } .inventory-table th:nth-child(3) { width:9%; } .inventory-table th:nth-child(4) { width:10%; } .inventory-table th:nth-child(5) { width:12%; } .inventory-table th:nth-child(6) { width:9%; } .inventory-table th:nth-child(7) { width:11%; } .inventory-table th:nth-child(8) { width:10%; } .inventory-table th:nth-child(9) { width:10%; } .inventory-table th:nth-child(10) { width:10%; } .inventory-table th:nth-child(11) { width:8%; } .inventory-table th:nth-child(12) { width:16%; }
		.inventory-table td { overflow-wrap:break-word; white-space:normal; }
		.inventory-table td:first-child strong { display:block; }
		.inventory-table td:first-child small { white-space:normal; }
		.inventory-table .inventory-actions { display:flex; flex-wrap:wrap; gap:8px; justify-content:flex-start; }
		.inventory-table .inventory-actions a, .inventory-table .inventory-actions button { display:inline-flex; align-items:center; min-height:30px; padding:6px 8px; color:var(--teal-dark); border:1px solid #cbd8d5; border-radius:5px; background:#f8faf9; cursor:pointer; font:12px Arial, sans-serif; text-decoration:none; }
		.inventory-table .inventory-actions a:hover, .inventory-table .inventory-actions button:hover { color:#fff; border-color:var(--teal); background:var(--teal); }
		.inventory-table .inventory-actions form { display:inline-flex; margin:0; }
		.detail-heading { flex-wrap:wrap; }
		.detail-heading .actions { max-width:100%; }
		.detail-grid { display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:10px; }
		.detail-item { min-width:0; padding:12px 14px; background:#f8faf9; border:1px solid #edf1ef; border-radius:6px; font:13px/1.45 Arial, sans-serif; }
		.detail-item span { display:block; margin-bottom:4px; color:var(--muted); font:bold 10px Arial, sans-serif; letter-spacing:.06em; text-transform:uppercase; }
		.detail-item strong { display:block; overflow-wrap:anywhere; color:var(--ink); font-weight:normal; }
		.label-sheet { width:min(440px, 100%); margin:0 auto; padding:28px; text-align:center; background:#fff; border:1px solid var(--line); border-radius:8px; }
		.label-sheet h2 { margin:0 0 6px; font-size:24px; font-weight:normal; }
		.label-sheet p { margin:0 0 18px; color:var(--muted); font:13px Arial, sans-serif; }
		.label-sheet img { display:block; width:220px; height:220px; margin:0 auto 18px; padding:8px; border:1px solid var(--line); }
		.label-details { display:grid; grid-template-columns:1fr 1fr; gap:10px; padding-top:16px; border-top:1px solid var(--line); text-align:left; }
		.label-details div { padding:9px; background:#f8faf9; border-radius:5px; }
		.label-details span { display:block; color:var(--muted); font:10px Arial, sans-serif; text-transform:uppercase; letter-spacing:.06em; }
		.label-details strong { display:block; margin-top:4px; font:13px Arial, sans-serif; overflow-wrap:anywhere; }
		.print-only { display:none; }
		.report-card, .category-chart { min-width:0; } .spend-row { display:flex; justify-content:space-between; align-items:baseline; padding:17px 20px; border-bottom:1px solid var(--line); color:var(--muted); font:13px Arial, sans-serif; } .spend-row strong { color:var(--ink); font:normal 24px Georgia, serif; }
		.report-note { margin:16px 20px 20px; color:var(--muted); font:11px/1.5 Arial, sans-serif; }
		.progress-row { padding:11px 20px 5px; font:12px Arial, sans-serif; } .progress-row > div:first-child { display:flex; justify-content:space-between; color:var(--muted); } .progress-row strong { color:var(--ink); } .progress-track, .bar-track { height:7px; margin-top:8px; overflow:hidden; background:#e7eeec; border-radius:10px; } .progress-track i, .bar-track i { display:block; height:100%; background:var(--teal); border-radius:10px; }
		.category-chart { grid-column:1 / -1; } .bars { padding:12px 20px 20px; } .bar-row { display:grid; grid-template-columns:90px 1fr 82px; gap:12px; align-items:center; padding:8px 0; color:var(--muted); font:12px Arial, sans-serif; } .bar-row strong { color:var(--ink); text-align:right; font-weight:normal; } .bar-track { margin-top:0; height:12px; } .bar-track i { background:var(--coral); }
		.overview-content { padding:22px 20px 25px; color:var(--muted); font:14px/1.7 Arial, sans-serif; }
		.overview-content p { margin:0 0 16px; } .overview-content strong { color:var(--ink); }
		.text-link { color:var(--teal); font-weight:bold; text-decoration:none; } .text-link:hover { color:var(--coral); }
		.guide { max-width:900px; } .steps { display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:0 30px; padding:10px 24px 24px; }
		.step { display:grid; grid-template-columns:42px 1fr; gap:12px; padding:19px 0; border-bottom:1px solid var(--line); }
		.step span { color:var(--coral); font:bold 12px Arial, sans-serif; letter-spacing:.08em; } .step h3 { margin:0 0 5px; font-size:17px; font-weight:normal; } .step p { margin:0; color:var(--muted); font:12px/1.55 Arial, sans-serif; }
		.alert { margin-bottom:20px; padding:12px 15px; color:var(--teal-dark); background:#dff2ed; border-radius:6px; font:13px Arial, sans-serif; } .alert.error { color:#963622; background:#fde3dc; }
		.empty { padding:45px 20px; color:var(--muted); text-align:center; font:13px Arial, sans-serif; }
		.site-footer { margin-top:32px; padding:20px 25px 24px; border-top:1px solid var(--line); background:rgba(255,255,255,.7); color:var(--muted); font:12px Arial, sans-serif; text-align:center; }
		.site-footer-inner { display:flex; justify-content:center; align-items:center; width:100%; gap:16px; max-width:1400px; margin:0 auto; text-align:center; }
		.site-footer-links { display:flex; gap:16px; flex-wrap:wrap; }
		.site-footer a { color:var(--teal-dark); text-decoration:none; }
		.site-footer a:hover { color:var(--coral); }
		.login-shell { display:grid; place-items:center; min-height:100vh; background:linear-gradient(135deg, #dff3f0 0%, #f5f7f4 40%, #eef4f3 100%); }
		.login-card { width:min(480px, 92vw); background:#fff; border:1px solid var(--line); border-radius:16px; box-shadow:0 18px 50px rgba(23, 35, 43, 0.08); padding:28px; }
		.login-card h2 { margin:0 0 8px; font-size:28px; font-weight:normal; }
		.login-subtitle { color:var(--muted); margin:0 0 20px; font:13px Arial, sans-serif; }
		.login-form .field { margin-bottom:14px; }
		.login-form button { width:100%; }
		.meta-list { display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:10px; }
		.meta-card { background:#fbfcfa; border:1px solid var(--line); border-radius:8px; padding:16px 18px; }
		.meta-card span { display:block; color:var(--muted); font:10px Arial, sans-serif; text-transform:uppercase; letter-spacing:.08em; }
		.meta-card strong { display:block; margin-top:7px; font-size:22px; font-weight:normal; }
		@media (max-width:900px) { .shell { display:block; } aside { position:static; padding:18px 22px; } .brand { margin-bottom:15px; } nav { display:flex; gap:5px; overflow:auto; } nav a { white-space:nowrap; } .side-note { display:none; } .workspace { grid-template-columns:1fr; } .inventory-panel .inventory-table { min-width:1500px; } .site-footer-inner { flex-direction:column; align-items:center; } }
		@media (max-width:650px) { main { padding:25px 15px; } .topline { display:block; } .stats, .overview-grid, .report-grid, .steps, .dashboard-grid { grid-template-columns:1fr 1fr; } .overview-welcome { display:block; padding:20px; } .overview-welcome .button { margin-top:16px; } .toolbar { display:block; } .toolbar select { width:100%; margin-top:8px; } .panel { overflow-x:hidden; } .panel table:not(.inventory-table) { min-width:760px; } .panel .inventory-table { display:block; min-width:0; width:100%; } .inventory-table thead { display:none; } .inventory-table tbody, .inventory-table tr { display:block; width:100%; } .inventory-table tr { margin-bottom:14px; padding:10px 14px; border:1px solid var(--line); border-radius:7px; background:#fff; } .inventory-table td { display:grid; grid-template-columns:96px minmax(0, 1fr); gap:12px; align-items:start; width:100%; padding:10px 0; border-top:1px solid #edf1ef; } .inventory-table td:first-child { border-top:0; } .inventory-table td::before { content:attr(data-label); color:var(--muted); font:bold 10px Arial, sans-serif; letter-spacing:.06em; text-transform:uppercase; } .inventory-table td:first-child strong { min-width:0; } .inventory-table td:last-child { display:block; } .inventory-table td:last-child::before { display:block; margin-bottom:8px; } .inventory-table .inventory-actions { gap:8px 12px; } .detail-heading .actions { width:100%; justify-content:flex-start; } .detail-heading .actions .button { flex:1 1 150px; } .detail-grid { grid-template-columns:1fr; } table { text-align:left; } .form { min-width:0; } }
		@media (max-width:480px) { .stats, .overview-grid, .report-grid, .steps { grid-template-columns:1fr; } .category-chart { grid-column:auto; } }
		@media print { body { background:#fff; } .print-controls, body > *:not(.printable-label) { display:none !important; } .print-only { display:block; } .label-sheet { width:90mm; margin:0; border:0; border-radius:0; padding:8mm; } }
	</style>
</head>
<body>
<?php if ($view === 'label' && $detailAsset !== null): ?>
<div class="printable-label">
	<div class="label-sheet">
		<div class="print-controls"><button class="button" type="button" onclick="window.print()">Print label</button> <a class="button secondary" href="index.php?view=inventory">Back to inventory</a></div>
		<h2><?= htmlspecialchars((string) ($detailAsset['name'] ?? 'Asset')) ?></h2>
		<p>Asset label · <?= htmlspecialchars((string) ($detailAsset['id'] ?? '')) ?></p>
		<img src="<?= qrCodeUrl((string) ($detailAsset['id'] ?? '')) ?>" alt="QR code for <?= htmlspecialchars((string) ($detailAsset['id'] ?? '')) ?>">
		<div class="label-details">
			<div><span>Serial</span><strong><?= htmlspecialchars((string) ($detailAsset['serial'] ?? 'Not set')) ?></strong></div>
			<div><span>Category</span><strong><?= htmlspecialchars((string) ($detailAsset['category'] ?? 'Other')) ?></strong></div>
			<div><span>Department</span><strong><?= htmlspecialchars((string) ($detailAsset['department'] ?? 'General')) ?></strong></div>
			<div><span>Location</span><strong><?= htmlspecialchars((string) ($detailAsset['location'] ?? 'Not set')) ?></strong></div>
		</div>
	</div>
</div>
<?php elseif ($view === 'login'): ?>
<div class="login-shell">
	<div class="login-card">
		<h2>Asset Ledger</h2>
		<p class="login-subtitle">Sign in to manage devices, departments, and service history.</p>
		<form method="post" class="login-form">
			<input type="hidden" name="action" value="login">
			<div class="field"><label for="username">Username</label><input id="username" name="username" value="admin" required></div>
			<div class="field"><label for="password">Password</label><input id="password" type="password" name="password" value="admin123" required></div>
			<button class="button" type="submit">Sign in</button>
		</form>
	</div>
</div>
<?php else: ?>
<div class="shell">
	<aside>
		<div class="brand"><div class="mark">AL</div><div><strong>Asset Ledger</strong><small>IT inventory</small></div></div>
		<nav>
			<a class="<?= $view === 'overview' ? 'active' : '' ?>" href="index.php?view=overview">Overview</a>
			<a class="<?= $view === 'inventory' || $view === 'process' ? 'active' : '' ?>" href="index.php?view=inventory">Inventory</a>
			<a class="<?= $view === 'requests' ? 'active' : '' ?>" href="index.php?view=requests">Requests</a>
			<a class="<?= $view === 'procurement' ? 'active' : '' ?>" href="index.php?view=procurement">Procurement</a>
			<a class="<?= $view === 'depreciation' ? 'active' : '' ?>" href="index.php?view=depreciation">Depreciation</a>
			<a class="<?= $view === 'scan' ? 'active' : '' ?>" href="index.php?view=scan">Scan</a>
			<a class="<?= $view === 'reservations' ? 'active' : '' ?>" href="index.php?view=reservations">Reservations</a>
			<a class="<?= $view === 'barcode' ? 'active' : '' ?>" href="index.php?view=barcode">Barcode</a>
			<a class="<?= $view === 'lifecycle' ? 'active' : '' ?>" href="index.php?view=lifecycle">Lifecycle</a>
			<a class="<?= $view === 'departments' ? 'active' : '' ?>" href="index.php?view=departments">Departments</a>
			<a class="<?= $view === 'maintenance' ? 'active' : '' ?>" href="index.php?view=maintenance">Maintenance</a>
			<a class="<?= $view === 'audit' ? 'active' : '' ?>" href="index.php?view=audit">Audit log</a>
			<a class="<?= $view === 'guide' ? 'active' : '' ?>" href="index.php?view=guide">Process guide</a>
			<form method="post" style="margin-top:10px;">
				<input type="hidden" name="action" value="logout">
				<button class="button secondary" type="submit" style="width:100%;">Logout</button>
			</form>
		</nav>
		<div class="side-note">A calm, reliable record of every device your team depends on.</div>
	</aside>
	<main>
		<div class="topline"><div><h1><?= $view === 'inventory' ? 'Inventory register' : ($view === 'process' ? 'Add an asset' : ($view === 'guide' ? 'The asset lifecycle' : ($view === 'lifecycle' ? 'Lifecycle history' : 'Good morning, IT team.'))) ?></h1><p class="intro">Keep every device accounted for, from purchase to retirement.</p></div></div>
		<?php if ($message !== ''): ?><div class="alert <?= $messageType === 'error' ? 'error' : '' ?>"><?= htmlspecialchars($message) ?></div><?php endif; ?>
		<?php if ($view === 'overview'): ?><section class="stats" aria-label="Inventory summary">
			<div class="stat"><span>Total assets</span><strong><?= $counts['total'] ?></strong></div>
			<div class="stat"><span>In use</span><strong><?= $counts['in_use'] ?></strong></div>
			<div class="stat"><span>Available</span><strong><?= $counts['available'] ?></strong></div>
			<div class="stat"><span>Needs attention</span><strong><?= $counts['maintenance'] ?></strong></div>
		</section><?php endif; ?>
		<?php if ($view === 'overview'): ?>
		<section class="overview-welcome">
			<div><span class="eyebrow">Asset overview</span><h2>Everything is in one place.</h2><p>Track your equipment at a glance, then jump into the detail only when you need it.</p></div>
			<a class="button" href="index.php?view=process">+ Add asset</a>
		</section>
		<section class="dashboard-grid">
			<div class="panel category-chart">
				<div class="panel-heading"><div><h2>Asset value by category</h2><span class="panel-meta">Where your inventory spend is concentrated</span></div><span class="report-period"><?= htmlspecialchars($currentYear) ?></span></div>
				<div class="bars"><?php if (count($categorySpend) === 0): ?><div class="empty">No category data available yet.</div><?php else: ?><?php foreach ($categorySpend as $category => $spend): ?><div class="bar-row"><span><?= htmlspecialchars($category) ?></span><div class="bar-track"><i style="width:<?= $maxCategorySpend > 0 ? round(($spend / $maxCategorySpend) * 100) : 0 ?>%"></i></div><strong><?= money($spend) ?></strong></div><?php endforeach; ?><?php endif; ?></div>
			</div>
			<div class="panel snapshot-card">
				<div class="panel-heading"><h2>At a glance</h2></div>
				<div class="snapshot-value"><span>Total asset value</span><strong><?= money($totalValue) ?></strong></div>
				<div class="snapshot-list"><div><span>Unassigned</span><strong><?= $unassignedCount ?></strong></div><div><span>Warranty soon</span><strong><?= $expiringSoonCount ?></strong></div><div><span>Open tickets</span><strong><?= count($maintenanceQueue) ?></strong></div></div>
			</div>
		</section>
		<section class="overview-grid overview-grid-compact">
			<div class="panel">
				<div class="panel-heading"><h2>Recent additions</h2><a class="text-link" href="index.php?view=inventory">View all</a></div>
				<div class="overview-content overview-list">
					<?php if (count($recentAssets) === 0): ?><p>No assets registered yet.</p><?php else: ?><?php foreach ($recentAssets as $asset): ?><p><strong><?= htmlspecialchars($asset['name']) ?></strong><span><?= htmlspecialchars($asset['category']) ?> · <?= money(assetCost($asset)) ?></span></p><?php endforeach; ?><?php endif; ?>
				</div>
			</div>
			<div class="panel">
				<div class="panel-heading"><h2>Needs attention</h2><a class="text-link" href="index.php?view=maintenance">Open queue</a></div>
				<div class="overview-content overview-list">
					<?php if (count($warrantyAlerts) === 0 && count($maintenanceQueue) === 0): ?><p>Nothing needs attention right now.</p><?php else: ?>
					<?php foreach (array_slice($warrantyAlerts, 0, 2) as $asset): $days = daysUntil((string) ($asset['warranty_until'] ?? '')); ?><p><strong><?= htmlspecialchars($asset['name']) ?></strong><span>Warranty ends in <?= abs($days) ?> day<?= abs($days) === 1 ? '' : 's' ?></span></p><?php endforeach; ?>
					<?php if (count($maintenanceQueue) > 0): ?><p><strong><?= count($maintenanceQueue) ?> maintenance ticket<?= count($maintenanceQueue) === 1 ? '' : 's' ?></strong><span>Review the open queue</span></p><?php endif; ?>
					<?php endif; ?>
				</div>
			</div>
		</section>
		<?php elseif ($view === 'departments'): ?>
		<section class="panel">
			<div class="panel-heading"><h2>Department overview</h2><span class="report-period"><?= count($departments) ?> departments</span></div>
			<div class="overview-content">
				<div class="meta-list">
				<?php foreach ($departments as $department): ?><div class="meta-card"><span><?= htmlspecialchars($department) ?></span><strong><?= (int) ($departmentCounts[$department] ?? 0) ?></strong></div><?php endforeach; ?>
				</div>
			</div>
		</section>
		<section class="panel" style="margin-top:24px; max-width:520px;">
			<div class="panel-heading"><h2>Add a department</h2></div>
			<div class="overview-content">
				<form method="post">
					<input type="hidden" name="action" value="save_department">
					<div class="field"><label for="new_department">Department name</label><input id="new_department" name="new_department" placeholder="e.g. Customer Success"></div>
					<button class="button" type="submit">Add department</button>
				</form>
			</div>
		</section>
		<?php elseif ($view === 'audit'): ?>
		<section class="panel">
			<div class="panel-heading"><h2>Audit history</h2><span class="report-period"><?= count($recentAuditEntries) ?> latest entries</span></div>
			<div class="overview-content">
				<?php if (count($recentAuditEntries) === 0): ?><p>No audit entries yet.</p><?php else: ?>
				<?php foreach ($recentAuditEntries as $entry): ?><p><strong><?= htmlspecialchars((string) ($entry['timestamp'] ?? '')) ?></strong> — <?= htmlspecialchars((string) ($entry['message'] ?? '')) ?></p><?php endforeach; ?>
				<?php endif; ?>
			</div>
		</section>
		<?php elseif ($view === 'detail' && $detailAsset !== null): ?>
		<section class="panel">
			<div class="panel-heading detail-heading"><div><h2><?= htmlspecialchars($detailAsset['name']) ?></h2><span class="panel-meta"><?= htmlspecialchars($detailAsset['id']) ?></span></div><div class="actions"><a class="button secondary" href="index.php?view=label&amp;detail=<?= urlencode((string) ($detailAsset['id'] ?? '')) ?>">Generate label</a><a class="button secondary" href="index.php?view=inventory">Back to inventory</a></div></div>
			<div class="overview-content">
				<div style="display:flex; gap:24px; align-items:flex-start; flex-wrap:wrap;">
					<div style="flex:1; min-width:260px;">
						<?php if (!empty($detailAsset['photo'] ?? '')): ?><div style="margin-bottom:18px;"><img src="<?= htmlspecialchars((string) $detailAsset['photo']) ?>" alt="<?= htmlspecialchars((string) ($detailAsset['name'] ?? 'Asset')) ?>" style="width:180px; height:180px; object-fit:cover; border:1px solid var(--line); border-radius:12px; background:#fff;"></div><?php endif; ?>
						<div class="detail-grid">
							<div class="detail-item"><span>Category</span><strong><?= htmlspecialchars((string) ($detailAsset['category'] ?? 'Other')) ?></strong></div>
							<div class="detail-item"><span>Department</span><strong><?= htmlspecialchars((string) ($detailAsset['department'] ?? 'General')) ?></strong></div>
							<div class="detail-item"><span>Status</span><strong><?= htmlspecialchars((string) ($detailAsset['status'] ?? 'Unknown')) ?></strong></div>
							<div class="detail-item"><span>Assigned to</span><strong><?= htmlspecialchars((string) ($detailAsset['assigned_to'] ?? '') !== '' ? (string) $detailAsset['assigned_to'] : 'Unassigned') ?></strong></div>
							<div class="detail-item"><span>Location</span><strong><?= htmlspecialchars((string) ($detailAsset['location'] ?? 'Not set')) ?></strong></div>
							<div class="detail-item"><span>Serial</span><strong><?= htmlspecialchars((string) ($detailAsset['serial'] ?? 'Not set')) ?></strong></div>
							<div class="detail-item"><span>Purchase date</span><strong><?= htmlspecialchars((string) ($detailAsset['purchase_date'] ?? 'Not set')) ?></strong></div>
							<div class="detail-item"><span>Warranty until</span><strong><?= htmlspecialchars((string) ($detailAsset['warranty_until'] ?? 'Not set')) ?></strong></div>
							<div class="detail-item"><span>Cost</span><strong><?= money(assetCost($detailAsset)) ?></strong></div>
							<div class="detail-item"><span>Notes</span><strong><?= htmlspecialchars((string) ($detailAsset['notes'] ?? 'No notes recorded.')) ?></strong></div>
						</div>
					</div>
					<div style="width:180px; text-align:center; padding:12px; background:#f9fbfa; border:1px solid var(--line); border-radius:8px;">
						<img src="<?= qrCodeUrl((string) ($detailAsset['id'] ?? '')) ?>" alt="QR code for <?= htmlspecialchars((string) ($detailAsset['id'] ?? '')) ?>" style="width:150px; height:150px; display:block; margin:0 auto 8px; background:#fff; padding:6px; border-radius:6px;">
						<small style="color:var(--muted); font:11px Arial, sans-serif;">Asset QR code</small>
					</div>
				</div>
			</div>
		</section>
		<section class="panel" style="margin-top:24px; max-width:520px;">
			<div class="panel-heading"><h2>Lifecycle actions</h2></div>
			<div class="form">
				<form method="post">
					<input type="hidden" name="action" value="transfer_asset">
					<input type="hidden" name="asset_id" value="<?= htmlspecialchars((string) ($detailAsset['id'] ?? '')) ?>">
					<div class="field"><label for="new_owner">New owner</label><input id="new_owner" name="new_owner" value="<?= htmlspecialchars((string) ($detailAsset['assigned_to'] ?? '')) ?>" placeholder="Assigned employee"></div>
					<div class="field"><label for="new_location">New location</label><input id="new_location" name="new_location" value="<?= htmlspecialchars((string) ($detailAsset['location'] ?? '')) ?>" placeholder="Office or site"></div>
					<div class="field"><label for="new_department">Department</label><select id="new_department" name="new_department"><?php foreach ($departments as $department): ?><option value="<?= htmlspecialchars($department) ?>" <?= (($detailAsset['department'] ?? 'General') === $department) ? 'selected' : '' ?>><?= htmlspecialchars($department) ?></option><?php endforeach; ?></select></div>
					<button class="button" type="submit">Transfer asset</button>
				</form>
				<form method="post" style="margin-top:16px;">
					<input type="hidden" name="action" value="retire_asset">
					<input type="hidden" name="asset_id" value="<?= htmlspecialchars((string) ($detailAsset['id'] ?? '')) ?>">
					<div class="field"><label for="retire_reason">Retirement reason</label><input id="retire_reason" name="retire_reason" value="End of lifecycle" placeholder="Reason for retirement"></div>
					<button class="button secondary" type="submit">Retire asset</button>
				</form>
			</div>
		</section>
		<?php elseif ($view === 'reservations'): ?>
		<section class="workspace">
			<div class="panel">
				<div class="panel-heading"><h2>Reserve an asset</h2></div>
				<div class="form">
					<form method="post">
						<input type="hidden" name="action" value="save_reservation">
						<div class="field"><label for="asset_id">Asset ID</label><input id="asset_id" name="asset_id" placeholder="AST-1001" required></div>
						<div class="form-grid">
							<div class="field"><label for="start_date">Start date</label><input id="start_date" type="date" name="start_date" required></div>
							<div class="field"><label for="end_date">End date</label><input id="end_date" type="date" name="end_date" required></div>
						</div>
						<div class="field"><label for="reserved_by">Reserved by</label><input id="reserved_by" name="reserved_by" value="<?= htmlspecialchars((string) ($loginUser ?? '')) ?>" placeholder="Requester name"></div>
						<div class="field"><label for="purpose">Purpose</label><input id="purpose" name="purpose" placeholder="Project or team use"></div>
						<button class="button" type="submit">Create reservation</button>
					</form>
				</div>
			</div>
			<div class="panel">
				<div class="panel-heading"><h2>Current reservations</h2></div>
				<div class="overview-content">
					<?php if (count($activeReservations) === 0): ?><p>No asset reservations are active at the moment.</p><?php else: ?>
					<?php foreach ($activeReservations as $reservation): ?><p><strong><?= htmlspecialchars((string) ($reservation['asset_name'] ?? 'Asset')) ?></strong> · <?= htmlspecialchars((string) ($reservation['asset_id'] ?? 'Unknown')) ?> · <?= htmlspecialchars((string) ($reservation['reserved_by'] ?? 'Unknown')) ?> · <?= htmlspecialchars((string) ($reservation['start_date'] ?? '')) ?> to <?= htmlspecialchars((string) ($reservation['end_date'] ?? '')) ?>
					<?php if (canManageAssets($loginRole) || ($loginUser !== null && $loginUser !== '' && (string) ($reservation['reserved_by'] ?? '') === (string) $loginUser)): ?>
					<form method="post" style="display:inline-block; margin-top:8px;">
						<input type="hidden" name="action" value="cancel_reservation">
						<input type="hidden" name="reservation_id" value="<?= htmlspecialchars((string) ($reservation['id'] ?? '')) ?>">
						<button class="button secondary" type="submit">Cancel</button>
					</form>
					<?php endif; ?></p><?php endforeach; ?>
					<?php endif; ?>
				</div>
			</div>
		</section>
		<?php elseif ($view === 'barcode'): ?>
		<section class="workspace">
			<div class="panel">
				<div class="panel-heading"><h2>Barcode check-in / check-out</h2></div>
				<div class="form">
					<form method="post">
						<input type="hidden" name="action" value="toggle_barcode_check">
						<div class="field"><label for="asset_id">Asset ID</label><input id="asset_id" name="asset_id" placeholder="AST-1001" required></div>
						<div class="field"><label for="type">Action</label><select id="type" name="type"><option value="checkin">Check in</option><option value="checkout">Check out</option></select></div>
						<div class="field"><label for="user">Handled by</label><input id="user" name="user" value="<?= htmlspecialchars((string) ($loginUser ?? '')) ?>" placeholder="User name"></div>
						<button class="button" type="submit">Apply barcode action</button>
					</form>
				</div>
			</div>
			<div class="panel">
				<div class="panel-heading"><h2>Recent barcode activity</h2></div>
				<div class="overview-content">
					<?php if (count($barcodeChecks) === 0): ?><p>No barcode activity has been recorded yet.</p><?php else: ?>
					<?php foreach (array_slice(array_reverse($barcodeChecks), 0, 6) as $entry): ?><p><strong><?= htmlspecialchars((string) ($entry['timestamp'] ?? '')) ?></strong> — <?= htmlspecialchars((string) ($entry['asset_id'] ?? 'Unknown')) ?> · <?= htmlspecialchars((string) ($entry['type'] ?? 'checkin')) ?> · <?= htmlspecialchars((string) ($entry['user'] ?? 'Unknown')) ?></p><?php endforeach; ?>
					<?php endif; ?>
				</div>
			</div>
		</section>
		<?php elseif ($view === 'scan'): ?>
		<section class="workspace">
			<div class="panel">
				<div class="panel-heading"><div><h2>Quick asset scan</h2><span class="panel-meta">Find by ID, serial, name, or location</span></div></div>
				<div class="form">
					<form method="post">
						<input type="hidden" name="action" value="scan_lookup">
						<div class="field"><label for="lookup">Search asset</label><input id="lookup" name="lookup" value="<?= htmlspecialchars($scanLookupValue) ?>" placeholder="AST-1001, serial, laptop, or Manila" required></div>
						<button class="button" type="submit">Find asset</button>
					</form>
				</div>
			</div>
			<?php if (count($scanResults) > 0): ?>
			<div class="panel">
				<div class="panel-heading"><div><h2>Scan results</h2><span class="panel-meta"><?= count($scanResults) ?> result<?= count($scanResults) === 1 ? '' : 's' ?></span></div></div>
				<div class="overview-content">
					<?php foreach ($scanResults as $result): ?>
					<p><strong><?= htmlspecialchars((string) ($result['name'] ?? 'Asset')) ?></strong><br><?= htmlspecialchars((string) ($result['id'] ?? '')) ?> · <?= htmlspecialchars((string) ($result['serial'] ?? 'No serial')) ?> · <?= htmlspecialchars((string) ($result['status'] ?? 'Unknown')) ?><br><?= htmlspecialchars((string) ($result['department'] ?? 'General')) ?> · <?= htmlspecialchars((string) ($result['location'] ?? 'Location not set')) ?> · <?= htmlspecialchars((string) ($result['assigned_to'] ?? 'Unassigned')) ?><br><a class="button secondary" href="index.php?view=detail&amp;detail=<?= urlencode((string) ($result['id'] ?? '')) ?>">Open asset</a></p>
					<?php endforeach; ?>
				</div>
			</div>
			<?php endif; ?>
			<div class="panel">
				<div class="panel-heading"><h2>Scan examples</h2></div>
				<div class="overview-content">
					<p><strong>Exact lookup:</strong> AST-1001 or DL5420-8K2P</p>
					<p><strong>Broader lookup:</strong> laptop, Finance, Maria, or Manila</p>
					<p>Use the scan flow to find a device quickly without opening the full inventory list.</p>
				</div>
			</div>
		</section>
		<?php elseif ($view === 'depreciation'): ?>
		<section class="panel">
			<div class="panel-heading"><div><h2>Asset depreciation</h2><span class="panel-meta"><?= count($replacementCandidates) ?> replacement candidates</span></div><a class="button" href="index.php?view=inventory">View inventory</a></div>
			<?php if (count($depreciatedAssets) === 0): ?><div class="empty">No asset records available for depreciation analysis.</div><?php else: ?>
			<table>
				<thead><tr><th>Asset</th><th>Age</th><th>Original cost</th><th>Current value</th><th>Replacement</th></tr></thead>
				<tbody>
				<?php foreach ($depreciatedAssets as $asset): ?>
				<tr>
					<td><strong><?= htmlspecialchars((string) ($asset['name'] ?? 'Asset')) ?></strong><small><?= htmlspecialchars((string) ($asset['id'] ?? '')) ?></small></td>
					<td><?= (int) floor((((int) ($asset['age_months'] ?? 0)) / 12)) ?> years / <?= (int) ($asset['age_months'] ?? 0) ?> months</td>
					<td><?= money((float) ($asset['cost'] ?? 0)) ?></td>
					<td><?= money((float) ($asset['estimated_value'] ?? 0)) ?></td>
					<td><span class="badge <?= shouldReplaceAsset($asset) ? 'maintenance' : '' ?>"><?= shouldReplaceAsset($asset) ? 'Recommend replace' : 'Monitor' ?></span></td>
				</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php endif; ?>
		</section>
		<?php elseif ($view === 'procurement'): ?>
		<section class="workspace">
			<div class="panel">
				<div class="panel-heading"><div><h2>Procurement requests</h2><span class="panel-meta"><?= count($pendingProcurements) ?> pending</span></div><a class="button" href="index.php?view=inventory">Browse inventory</a></div>
				<?php if (count($procurementRequests) === 0): ?><div class="empty">No procurement requests have been submitted yet.</div><?php else: ?>
				<table>
					<thead><tr><th>Item</th><th>Vendor</th><th>Cost</th><th>Status</th><th>Action</th></tr></thead>
					<tbody>
					<?php foreach ($procurementRequests as $request): ?>
					<tr>
						<td><strong><?= htmlspecialchars((string) ($request['item_name'] ?? 'Unnamed purchase')) ?></strong><small><?= htmlspecialchars((string) ($request['reason'] ?? '')) ?></small></td>
						<td><?= htmlspecialchars((string) ($request['vendor'] ?? 'Unknown')) ?></td>
						<td><?= money((float) ($request['estimated_total'] ?? 0)) ?></td>
						<td><span class="badge <?= (($request['status'] ?? 'Pending') === 'Approved' ? 'maintenance' : (($request['status'] ?? 'Pending') === 'Rejected' ? 'retired' : '')) ?>"><?= htmlspecialchars((string) ($request['status'] ?? 'Pending')) ?></span></td>
						<td>
						<?php if (canManageAssets($loginRole) && (($request['status'] ?? 'Pending') === 'Pending')): ?>
						<form method="post" style="display:flex; gap:8px; align-items:center;">
							<input type="hidden" name="action" value="respond_procurement">
							<input type="hidden" name="request_id" value="<?= htmlspecialchars((string) ($request['id'] ?? '')) ?>">
							<select name="decision"><option value="approved">Approve</option><option value="rejected">Reject</option></select>
							<button class="button secondary" type="submit">Apply</button>
						</form>
						<?php else: ?>
						<span style="color:#68777d; font-size:12px;">No action</span>
						<?php endif; ?>
						</td>
					</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<?php endif; ?>
			</div>
			<div class="panel">
				<div class="panel-heading"><h2>New procurement request</h2></div>
				<div class="form">
					<form method="post">
						<input type="hidden" name="action" value="save_procurement">
						<div class="field"><label for="item_name">Item name</label><input id="item_name" name="item_name" placeholder="Laptop, monitor, access point" required></div>
						<div class="form-grid">
							<div class="field"><label for="vendor">Vendor</label><input id="vendor" name="vendor" placeholder="Supplier or reseller" required></div>
							<div class="field"><label for="category">Category</label><select id="category" name="category"><?php foreach ($categories as $category): ?><option><?= htmlspecialchars($category) ?></option><?php endforeach; ?></select></div>
						</div>
						<div class="form-grid">
							<div class="field"><label for="quantity">Quantity</label><input id="quantity" name="quantity" type="number" min="1" value="1"></div>
							<div class="field"><label for="unit_cost">Unit cost</label><input id="unit_cost" name="unit_cost" type="number" min="0" step="0.01" value="0"></div>
						</div>
						<div class="form-grid">
							<div class="field"><label for="urgency">Urgency</label><select id="urgency" name="urgency"><option>Low</option><option selected>Medium</option><option>High</option><option>Critical</option></select></div>
							<div class="field"><label for="requested_by">Requested by</label><input id="requested_by" name="requested_by" value="<?= htmlspecialchars((string) ($loginUser ?? '')) ?>" placeholder="Staff member"></div>
						</div>
						<div class="field"><label for="reason">Business need</label><textarea id="reason" name="reason" placeholder="Explain why this purchase is needed..." required></textarea></div>
						<button class="button" type="submit">Submit purchase request</button>
					</form>
				</div>
			</div>
		</section>
		<?php elseif ($view === 'requests'): ?>
			<div class="panel">
				<div class="panel-heading"><div><h2>Asset requests</h2><span class="panel-meta"><?= count($pendingRequests) ?> pending</span></div><a class="button" href="index.php?view=inventory">Browse inventory</a></div>
				<?php if (count($assetRequests) === 0): ?><div class="empty">No asset requests have been submitted yet.</div><?php else: ?>
				<table>
					<thead><tr><th>Request</th><th>By</th><th>Urgency</th><th>Status</th><th>Action</th></tr></thead>
					<tbody>
					<?php foreach ($assetRequests as $request): ?>
					<tr>
						<td><strong><?= htmlspecialchars((string) ($request['asset_name'] ?? 'Untitled request')) ?></strong><small><?= htmlspecialchars((string) ($request['reason'] ?? '')) ?></small></td>
						<td><?= htmlspecialchars((string) ($request['requested_by'] ?? 'Unknown')) ?></td>
						<td><?= htmlspecialchars((string) ($request['urgency'] ?? 'Medium')) ?></td>
						<td><span class="badge <?= (($request['status'] ?? 'Pending') === 'Approved' ? 'maintenance' : (($request['status'] ?? 'Pending') === 'Rejected' ? 'retired' : '')) ?>"><?= htmlspecialchars((string) ($request['status'] ?? 'Pending')) ?></span></td>
						<td>
						<?php if (canManageAssets($loginRole) && (($request['status'] ?? 'Pending') === 'Pending')): ?>
						<form method="post" style="display:flex; gap:8px; align-items:center;">
							<input type="hidden" name="action" value="respond_request">
							<input type="hidden" name="request_id" value="<?= htmlspecialchars((string) ($request['id'] ?? '')) ?>">
							<select name="decision"><option value="approved">Approve</option><option value="rejected">Reject</option></select>
							<button class="button secondary" type="submit">Apply</button>
						</form>
						<?php else: ?>
						<span style="color:#68777d; font-size:12px;">No action</span>
						<?php endif; ?>
					</td>
					</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<?php endif; ?>
			</div>
			<div class="panel">
				<div class="panel-heading"><h2>New request</h2></div>
				<div class="form">
					<form method="post">
						<input type="hidden" name="action" value="save_request">
						<div class="field"><label for="asset_name">Requested asset</label><input id="asset_name" name="asset_name" placeholder="Laptop or printer" required></div>
						<div class="form-grid">
							<div class="field"><label for="category">Category</label><select id="category" name="category"><?php foreach ($categories as $category): ?><option><?= htmlspecialchars($category) ?></option><?php endforeach; ?></select></div>
							<div class="field"><label for="quantity">Quantity</label><input id="quantity" name="quantity" type="number" min="1" value="1"></div>
						</div>
						<div class="form-grid">
							<div class="field"><label for="urgency">Urgency</label><select id="urgency" name="urgency"><option>Low</option><option selected>Medium</option><option>High</option><option>Critical</option></select></div>
							<div class="field"><label for="requested_by">Requested by</label><input id="requested_by" name="requested_by" value="<?= htmlspecialchars((string) ($loginUser ?? '')) ?>" placeholder="Staff member"></div>
						</div>
						<div class="field"><label for="reason">Reason</label><textarea id="reason" name="reason" placeholder="Explain the request and its business need..." required></textarea></div>
						<button class="button" type="submit">Submit request</button>
					</form>
				</div>
			</div>
		</section>
		<?php elseif ($view === 'lifecycle'): ?>
		<section class="panel">
			<div class="panel-heading"><h2>Lifecycle timeline</h2><span class="report-period"><?= count($lifecycleEvents) ?> tracked events</span></div>
			<div class="overview-content">
				<?php if (count($lifecycleEvents) === 0): ?><p>No lifecycle events have been recorded yet.</p><?php else: ?>
				<?php foreach ($lifecycleEvents as $event): ?>
				<p><strong><?= htmlspecialchars((string) ($event['timestamp'] ?? '')) ?></strong> — <?= htmlspecialchars((string) ($event['asset_id'] ?? 'Unknown')) ?> · <?= htmlspecialchars((string) ($event['event'] ?? '')) ?> · <?= htmlspecialchars((string) ($event['details'] ?? '')) ?></p>
				<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</section>
		<?php elseif ($view === 'guide'): ?>
		<section class="panel guide"><div class="panel-heading"><h2>Recommended asset process</h2></div><div class="steps"><div class="step"><span>01</span><div><h3>Receive</h3><p>When equipment arrives, confirm the model, serial number, and condition.</p></div></div><div class="step"><span>02</span><div><h3>Register</h3><p>Add the asset before assigning it. Include its purchase and warranty dates.</p></div></div><div class="step"><span>03</span><div><h3>Assign</h3><p>Record the person, team, and location responsible for the equipment.</p></div></div><div class="step"><span>04</span><div><h3>Maintain</h3><p>Use the status and notes to track repairs, replacements, and changes.</p></div></div><div class="step"><span>05</span><div><h3>Retire</h3><p>Mark old equipment as retired rather than deleting its history.</p></div></div></div></section>
		<section class="panel guide" style="margin-top:24px;">
			<div class="panel-heading"><h2>Now included in this system</h2></div>
			<div class="overview-content">
				<p><strong>1.</strong> Department tracking with custom department creation.</p>
				<p><strong>2.</strong> Maintenance ticket board linked to asset records.</p>
				<p><strong>3.</strong> Audit history for registration, edits, and removals.</p>
				<p><strong>4.</strong> Search, filter, and export for inventory operations.</p>
				<p><strong>5.</strong> Dashboard intelligence for spending, aging, and warranty alerts.</p>
			</div>
		</section>
		<?php elseif ($view === 'maintenance'): ?>
		<section class="workspace">
			<div class="panel">
				<div class="panel-heading"><div><h2>Maintenance board</h2><span class="panel-meta"><?= count($maintenanceQueue) ?> open tickets</span></div><a class="button" href="index.php?view=inventory">View inventory</a></div>
				<?php if (count($maintenanceQueue) === 0): ?><div class="empty">No active maintenance tickets.</div><?php else: ?>
				<table>
					<thead><tr><th>Ticket</th><th>Asset</th><th>Priority</th><th>Status</th><th>Created</th></tr></thead>
					<tbody>
					<?php foreach ($maintenanceQueue as $ticket): ?>
					<tr>
						<td><strong><?= htmlspecialchars((string) ($ticket['title'] ?? 'Untitled ticket')) ?></strong><small><?= htmlspecialchars((string) ($ticket['description'] ?? '')) ?></small></td>
						<td><?= htmlspecialchars((string) ($ticket['asset_id'] ?? 'Unknown')) ?></td>
						<td><?= htmlspecialchars((string) ($ticket['priority'] ?? 'Medium')) ?></td>
						<td><span class="badge <?= ($ticket['status'] ?? 'Open') === 'Open' ? '' : 'maintenance' ?>"><?= htmlspecialchars((string) ($ticket['status'] ?? 'Open')) ?></span></td>
						<td><?= htmlspecialchars((string) ($ticket['created_at'] ?? '')) ?></td>
					</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<?php endif; ?>
			</div>
			<div class="panel">
				<div class="panel-heading"><h2>Create ticket</h2></div>
				<div class="form">
					<form method="post">
						<input type="hidden" name="action" value="save_ticket">
						<div class="field"><label for="asset_id">Asset ID</label><input id="asset_id" name="asset_id" placeholder="AST-1001" required></div>
						<div class="field"><label for="title">Ticket title</label><input id="title" name="title" placeholder="Replace keyboard or battery" required></div>
						<div class="field"><label for="description">Issue details</label><textarea id="description" name="description" placeholder="Describe the issue and the requested action..."></textarea></div>
						<div class="form-grid">
							<div class="field"><label for="priority">Priority</label><select id="priority" name="priority"><option>Low</option><option selected>Medium</option><option>High</option><option>Critical</option></select></div>
							<div class="field"><label for="status">Status</label><select id="status" name="status"><option selected>Open</option><option>In progress</option><option>Waiting on vendor</option><option>Completed</option></select></div>
						</div>
						<button class="button" type="submit">Save ticket</button>
					</form>
				</div>
			</div>
		</section>
		<?php elseif ($view === 'inventory'): ?>
		<div class="workspace">
			<section class="panel inventory-panel" id="inventory">
				<div class="panel-heading"><div><h2>Inventory register</h2><span class="panel-meta"><?= count($filteredAssets) ?> shown</span></div><div class="actions" style="display:flex; align-items:center; gap:12px;"><a class="button secondary" href="index.php?view=inventory&export=csv<?= $search !== '' ? '&search=' . urlencode($search) : '' ?><?= $statusFilter !== 'All' ? '&status=' . urlencode($statusFilter) : '' ?>">Export CSV</a><button class="button" type="button" onclick="window.location.href='index.php?view=process'">+ Register asset</button></div></div>
				<form class="toolbar" method="get"><input type="hidden" name="view" value="inventory"><input name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search name, serial, person or location..." onchange="this.form.submit()"><select name="status" onchange="this.form.submit()"><option>All</option><?php foreach ($statuses as $status): ?><option <?= $statusFilter === $status ? 'selected' : '' ?>><?= $status ?></option><?php endforeach; ?></select><select name="department" onchange="this.form.submit()"><option value="All" <?= $departmentFilter === 'All' ? 'selected' : '' ?>>All departments</option><?php foreach ($departments as $department): ?><option value="<?= htmlspecialchars($department) ?>" <?= $departmentFilter === $department ? 'selected' : '' ?>><?= htmlspecialchars($department) ?></option><?php endforeach; ?></select><select name="sort" onchange="this.form.submit()"><option value="name_asc" <?= $sort === 'name_asc' ? 'selected' : '' ?>>Sort: Name A-Z</option><option value="name_desc" <?= $sort === 'name_desc' ? 'selected' : '' ?>>Sort: Name Z-A</option><option value="status_asc" <?= $sort === 'status_asc' ? 'selected' : '' ?>>Sort: Status</option><option value="cost_desc" <?= $sort === 'cost_desc' ? 'selected' : '' ?>>Sort: Highest cost</option><option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Sort: Newest</option></select><?php if ($search !== '' || $statusFilter !== 'All' || $departmentFilter !== 'All' || $sort !== 'name_asc'): ?><a class="text-link" href="index.php?view=inventory" style="display:inline-flex;align-items:center;justify-content:center;padding:11px 12px;border:1px solid #cbd8d5;border-radius:5px;text-decoration:none;">Reset</a><?php endif; ?></form>
				<?php if (count($filteredAssets) === 0): ?><div class="empty">No assets match this search. Try a different filter or register a new asset.</div><?php else: ?>
				<table class="inventory-table"><thead><tr><th>ID</th><th>Asset</th><th>Category</th><th>Department</th><th>Serial</th><th>Status</th><th>Assigned to</th><th>Location</th><th>Purchase date</th><th>Warranty until</th><th>Cost</th><th>Actions</th></tr></thead><tbody>
				<?php foreach ($filteredAssets as $asset): ?><tr><td data-label="ID"><?= htmlspecialchars((string) ($asset['id'] ?? 'Not set')) ?></td><td data-label="Asset"><strong><?= htmlspecialchars((string) ($asset['name'] ?? 'Asset')) ?></strong></td><td data-label="Category"><?= htmlspecialchars((string) ($asset['category'] ?? 'Other')) ?></td><td data-label="Department"><?= htmlspecialchars((string) ($asset['department'] ?? 'General')) ?></td><td data-label="Serial"><?= htmlspecialchars((string) ($asset['serial'] ?? 'Not set')) ?></td><td data-label="Status"><span class="badge <?= statusChipClass((string) ($asset['status'] ?? '')) ?>"><?= htmlspecialchars((string) ($asset['status'] ?? 'Unknown')) ?></span></td><td data-label="Assigned to"><?= htmlspecialchars((string) ($asset['assigned_to'] ?? '') !== '' ? (string) $asset['assigned_to'] : 'Unassigned') ?></td><td data-label="Location"><?= htmlspecialchars((string) ($asset['location'] ?? 'Not set')) ?></td><td data-label="Purchase date"><?= htmlspecialchars((string) ($asset['purchase_date'] ?? 'Not set')) ?></td><td data-label="Warranty until"><?= htmlspecialchars((string) ($asset['warranty_until'] ?? 'Not set')) ?></td><td data-label="Cost"><?= money(assetCost($asset)) ?></td><td data-label="Actions"><div class="inventory-actions"><a href="?view=detail&detail=<?= urlencode((string) $asset['id']) ?>">Details</a><a href="?view=label&detail=<?= urlencode((string) $asset['id']) ?>">Label</a><a href="?view=process&edit=<?= urlencode((string) $asset['id']) ?>">Edit</a><form method="post" onsubmit="return confirm('Remove this asset from the inventory?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= htmlspecialchars((string) $asset['id']) ?>"><button type="submit">Remove</button></form></div></td></tr><?php endforeach; ?></tbody></table>
				<?php endif; ?>
			</section>
		</div>
		<?php elseif ($view === 'process'): ?>
		<div class="workspace single-column">
			<section class="panel" id="process">
				<form class="form" method="post" enctype="multipart/form-data"><h3><?= $editingAsset ? 'Update asset' : 'Register an asset' ?></h3><p>Capture the identity and ownership details you will need later.</p><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= htmlspecialchars($editingAsset['id'] ?? '') ?>">
					<div class="field"><label for="name">Asset name *</label><input id="name" name="name" required value="<?= htmlspecialchars($editingAsset['name'] ?? '') ?>" placeholder="e.g. Lenovo ThinkPad T14"></div>
					<div class="form-grid"><div class="field"><label for="category">Category</label><select id="category" name="category"><?php foreach ($categories as $category): ?><option <?= ($editingAsset['category'] ?? '') === $category ? 'selected' : '' ?>><?= $category ?></option><?php endforeach; ?></select></div><div class="field"><label for="status">Status</label><select id="status" name="status"><?php foreach ($statuses as $status): ?><option <?= ($editingAsset['status'] ?? 'Available') === $status ? 'selected' : '' ?>><?= $status ?></option><?php endforeach; ?></select></div></div>
					<div class="form-grid"><div class="field"><label for="department">Department</label><select id="department" name="department"><?php foreach ($departments as $department): ?><option value="<?= htmlspecialchars($department) ?>" <?= (($editingAsset['department'] ?? 'General') === $department) ? 'selected' : '' ?>><?= htmlspecialchars($department) ?></option><?php endforeach; ?></select></div><div class="field"><label for="serial">Serial number *</label><input id="serial" name="serial" required value="<?= htmlspecialchars($editingAsset['serial'] ?? '') ?>" placeholder="Manufacturer serial number"></div></div>
					<div class="form-grid"><div class="field"><label for="assigned_to">Assigned to</label><input id="assigned_to" name="assigned_to" value="<?= htmlspecialchars($editingAsset['assigned_to'] ?? '') ?>" placeholder="Person or team"></div><div class="field"><label for="location">Location</label><input id="location" name="location" value="<?= htmlspecialchars($editingAsset['location'] ?? '') ?>" placeholder="Office or room"></div></div>
					<div class="form-grid"><div class="field"><label for="purchase_date">Purchase date</label><input id="purchase_date" type="date" name="purchase_date" value="<?= htmlspecialchars($editingAsset['purchase_date'] ?? '') ?>"></div><div class="field"><label for="warranty_until">Warranty until</label><input id="warranty_until" type="date" name="warranty_until" value="<?= htmlspecialchars($editingAsset['warranty_until'] ?? '') ?>"></div></div>
					<div class="field"><label for="cost">Purchase cost</label><input id="cost" type="number" min="0" step="0.01" name="cost" value="<?= htmlspecialchars((string) ($editingAsset['cost'] ?? '')) ?>" placeholder="0.00"></div>
					<div class="field"><label for="photo">Asset photo</label><input id="photo" name="photo" type="file" accept="image/png,image/jpeg,image/webp,image/gif"> <?php if (!empty($editingAsset['photo'] ?? '')): ?><span style="display:block; margin-top:6px; color:var(--muted); font:11px Arial, sans-serif;">Current photo: <?= htmlspecialchars((string) ($editingAsset['photo'] ?? '')) ?></span><?php endif; ?></div>
					<div class="field"><label for="notes">Notes</label><textarea id="notes" name="notes" placeholder="Condition, accessories, or service notes..."><?= htmlspecialchars($editingAsset['notes'] ?? '') ?></textarea></div>
					<div class="form-actions"><button class="button" type="submit"><?= $editingAsset ? 'Save changes' : 'Add to inventory' ?></button><?php if ($editingAsset): ?><a class="button secondary" href="index.php">Cancel</a><?php endif; ?></div>
				</form>
			</section>
		</div>
		<?php endif; ?>
	</main>
</div>
<?php endif; ?>
<?php if ($view !== 'login'): ?>
<footer class="site-footer">
	<div class="site-footer-inner">
		<div>© <?= htmlspecialchars((string) date('Y')) ?> Asset Ledger. IT inventory made simple.</div>
	</div>
</footer>
<?php endif; ?>
</body>
</html>
